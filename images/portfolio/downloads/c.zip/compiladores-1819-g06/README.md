# Projeto de Compiladores
Este repositório serve como uma ferramenta de apoio ao desenvolvimento do projeto prático da UC de Compiladores da Universidade de Aveiro, a construção de um compilador para uma linguagem de análise dimensional para o ramo da física.

# Autores
* **Alina Yanchuk**
* **Diogo Silva**
* **João Vasconcelos**
* **Tiago Mendes**
* **Vasco Ramos**
