function Cell(i,j,w){
	//i = y
	//j = x
	this.i = i;
	this.j = j;
	this.x = j*w;
	this.y = i*w;
	this.w = w;
	this.bomb = false;
	this.revealed = false;
	this.marker = false;
	this.bombsAround = 0;
}

Cell.prototype.show = function(){
	stroke(150);
	noFill();
	rect(this.x,this.y,this.w,this.w);
	if(this.revealed){
		if(this.bomb){
			if(this.marker){
				fill(158, 127, 56);
				triangle(this.x+5,this.y+5,this.x+5,this.y+this.w-5,this.x+this.w-5,this.y+this.w*0.5);
			}else{
				fill(70);
				rect(this.x,this.y,this.w,this.w);
				fill(158, 127, 56);
				ellipse(this.x+this.w*0.5,this.y+this.w*0.5,this.w*0.5,this.w*0.5);
			}
		
		}else{
			if(this.marker){
				fill(158, 127, 56);
				triangle(this.x+5,this.y+5,this.x+5,this.y+this.w-5,this.x+this.w-5,this.y+this.w*0.5);
			}else{
				fill(70);
				rect(this.x,this.y,this.w,this.w);
				if(this.bombsAround!= 0){
					fill(255);
					textSize(20);
					text(this.bombsAround,this.x+this.w*0.5-5,this.y+this.w*0.5+5);
				}
			}
		}
	}
}

Cell.prototype.contains = function(x,y){
	return (x>this.x && x<this.x+this.w && y>this.y && y<this.y+this.w)
}

Cell.prototype.reveal = function(){
	this.revealed = true;
	this.marker = false;
	if (this.bombsAround == 0){
		this.revealNoBombs();
	}
}

Cell.prototype.markerMaker = function(){
	this.revealed = true;
	this.marker = true;
}

Cell.prototype.countBombNeighbors = function(){
	if (this.bomb){
		return this.bombsAround=-1;
	}
	var total = 0;
	
	for (var yoff = -1; yoff<=1 ; yoff++){
		for (var xoff = -1; xoff<=1 ; xoff++){
			var j = this.j + xoff;
			var i = this.i + yoff;
			if ( j > -1 && j<cols && i>-1 && i<rows){
				var neighbor = grid[i][j];
				if (neighbor.bomb){
					total++
				}
			}
		}
	}
	this.bombsAround = total;
}

Cell.prototype.revealNoBombs = function(){
	for (var yoff = -1; yoff<=1 ; yoff++){
		for (var xoff = -1; xoff<=1 ; xoff++){
			var j = this.j + xoff;
			var i = this.i + yoff;
			if ( j > -1 && j<cols && i>-1 && i<rows){
				var neighbor = grid[i][j];
				if (!neighbor.bomb && !neighbor.revealed){
					neighbor.reveal();
				}
			}
		}
	}
}

