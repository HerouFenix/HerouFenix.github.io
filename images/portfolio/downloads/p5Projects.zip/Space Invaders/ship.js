///////////////////Ship
function shipMaker(){
	this.x = width/2-30;
	this.y = 600;
	this.xSpeed = 0;

	this.show = function(){
		noStroke();
		fill(255);
		rect(this.x,this.y,60,20);
		rect(this.x+20,this.y-10,20,10);
	}

	this.moveShip = function(){
		this.x = this.x+this.xSpeed;
		this.x = constrain(this.x,0,width-60);
	}
}