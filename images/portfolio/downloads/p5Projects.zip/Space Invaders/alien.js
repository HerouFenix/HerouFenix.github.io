///////////////////Aliens

function alien(x,y){
	this.x = x;
	this.y = y;
	this.life = 1
	this.xSpeed = -1;

	this.show = function(){
		if (this.life == 1){
			fill(255);
		}else{
			fill(255,0,0)
		}
		ellipse(this.x,this.y,20,20);
	}

	this.update = function(){
		this.x = this.x+this.xSpeed;
		this.x = constrain(this.x,10,width-10);
	}

	this.checkWall = function(){
		if (this.x == 10 || this.x == width-10){
			return true;
		}
	}

	this.moveDown = function(){
		this.xSpeed = -this.xSpeed;
		this.y = this.y+40;
	}
}