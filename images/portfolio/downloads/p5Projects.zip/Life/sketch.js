//Conway's Game of Life

function make2DArray(rows,cols){
	var myArray = new Array(rows)
	for (var i = 0; i < myArray.length; i++){
		myArray[i] = new Array(cols);
	}
	return myArray;
}

function countNeighbors(grid,row,col){
	var sum = 0;
	for (var i = -1; i<2; i++){
  		for (var j = -1; j<2; j++){
  			
			//IMPORTANT!!! I used the modulus down there cus it makes it so on edge cases they loop over to the other side !!!!!!!!!!!!!!!!!!!!!!!1
  			var neighborRow = (row+i+rows)%rows;
  			var neighborCol = (col+j+cols)%cols;

  			sum += grid[neighborRow][neighborCol];

  		}
  	}

  	sum-= grid[row][col] ;

  	return sum;
}


var grid;
var cols;
var rows;
var resolution = 10;

function setup() {
	createCanvas(600,600);
	cols = width/resolution;
	rows = height/resolution;
	grid = make2DArray(rows,cols);
	for (var i = 0; i<rows; i++){
 		for (var j = 0; j<cols; j++){
  			grid[i][j] = floor(random(2));
 		}
  }
}

function draw() {
 	background(51);

 	for (var i = 0; i<rows; i++){
  		for (var j = 0; j<cols; j++){

  			if (grid[i][j] == 1){
  				fill(255);
  				stroke(0);
  				rect(i*resolution,j*resolution,resolution-1,resolution-1);

  			}
  		}
  	}

  var next = make2DArray(rows,cols);

	for (var i = 0; i<rows; i++){
  		for (var j = 0; j<cols; j++){
  			var state = grid[i][j];
  			var sumNeighbors = countNeighbors(grid,i,j);

  			if (state == 0 && sumNeighbors == 3){
  				next[i][j] = 1;
  			}else if (state ==1 && (sumNeighbors<2 || sumNeighbors>3)){
  				next[i][j] = 0;
  			}else{
  				next[i][j] = state;
  			}
  		}
  	}
 	grid = next;
}


