let m1;
let m2;
let l1;
let l2;
let a1 = Math.PI/2;
let a2 = 0;
let a1_v = 0;
let a2_v = 0;
let g;

let cx,cy;
let px,py;

let trace;

let gSlider;
let m1Slider;
let m2Slider;
let l1Slider;
let l2Slider;

let reset;
let resetSl;
let pauseBt;
let unpauseBt;
let restartBt;

function setup() {
  createCanvas(800,600);
  cx = width/2;
  cy = 50;

  resetTrace();
  console.log('Slider Order: g ; m1 ; m2 ; l1 ; l2')
  gSlider = createSlider(-10,10,1,1);
  m1Slider = createSlider(0,100,30,1);
  m2Slider = createSlider(0,100,30,1);
  l1Slider = createSlider(0,350,150,1);
  l2Slider = createSlider(0,350,150,1);

  pauseBt = createButton('Pause');
  pauseBt.mousePressed(pause);
  unpauseBt = createButton('Unpause');
  unpauseBt.mousePressed(unpause);

  reset = createButton('Clear');
  reset.mousePressed(resetTrace);
  resetSl = createButton('Reset');
  resetSl.mousePressed(resetSliders);

  restartBt = createButton('Restart');
  restartBt.mousePressed(restart);
}

function resetTrace(){
  trace = createGraphics(800,600);
  trace.translate(map(cx,0,width,0,width/2),map(cy,0,height,0,height/2));	
}

function restart(){
  a1 = Math.PI/2;
  a2 = 0;
  a1_v = 0;
  a2_v = 0;
  resetTrace();
}

function resetSliders(){
  gSlider.value(1);
  m1Slider.value(30);
  m2Slider.value(30);
  l1Slider.value(150);
  l2Slider.value(150);
}


function draw() {
  background(51);
  image(trace,0,0);

  m1 = m1Slider.value();
  m2 = m2Slider.value();
  g = gSlider.value();
  l1 = l1Slider.value();
  l2 = l2Slider.value();


  let num1 = -g * (2*m1+m2)*sin(a1);
  let num2 = -m2*g*sin(a1-2*a2);
  let num3 = -2*sin(a1-a2)*m2;
  let num4 = a2_v*a2_v*l2 + a1_v*a1_v*l1*cos(a1-a2);
  let den = l1*(2*m1+m2-m2*cos(2*a1-2*a2));

  let a1_a = (num1+num2+num3*num4)/den;

  num1 = 2*sin(a1-a2);
  num2 = a1_v*a1_v*l1*(m1+m2);
  num3 = g*(m1+m2)*cos(a1);
  num4 = a2_v*a2_v*l2*m2*cos(a1-a2);
  den = l2*(2*m1+m2-m2*cos(2*a1-2*a2));

  let a2_a = (num1*(num2+num3+num4))/den;

  translate(cx,cy);
  fill(255);
  stroke(255);
  strokeWeight(2);

  let x1 = l1 * sin(a1);
  let y1 = l1 * cos(a1);

  let x2 = l2 * sin(a2) + x1;
  let y2 = l2 * cos(a2) + y1;

  line(0,0,x1,y1);
  ellipse(x1,y1,m1,m1);

  line(x1,y1,x2,y2);
  ellipse(x2,y2,m2,m2);

  a1_v += a1_a;
  a2_v += a2_a;
  a1 += a1_v;
  a2 += a2_v;


  trace.stroke(0,0,255);
  trace.strokeWeight(1);
  trace.line(map(x2,0,width,0,width/2),map(y2,0,height,0,height/2),px,py);
  px = map(x2,0,width,0,400);
  py = map(y2,0,height,0,300);
}

function pause(){
	noLoop();
}
function unpause(){
	loop();
}