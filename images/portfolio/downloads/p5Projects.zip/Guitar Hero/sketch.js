var guitar;
var lines;
var notes = [];
var score = 0;

function setup() {
  createCanvas(400,700);
  frameRate(30);
  guitar = new guitar();
  lines = new lines();
}

function draw() {
  background(51);
  guitar.show()
  textSize(25);
  stroke(255,100);
  text('Score: '+score, 5, 25);

  lines.show();

  if (frameCount%15 == 0){
    notes.push(new note());
  }
  for (var i = notes.length-1; i>=0;i--){
    notes[i].show();
    notes[i].update();
    if (notes[i].finish()){
      score = score+notes[i].scoreCounter();
      notes.splice(i,1);
    }
  }

}

function keyPressed(){
	if (keyCode === LEFT_ARROW){
		guitar.dir(-80);
	}else if (keyCode === RIGHT_ARROW){
		guitar.dir(+80);
	}if (key === ' '){
		guitar.pluck(notes)
    score = score + guitar.scoreCounter();
	}
}
