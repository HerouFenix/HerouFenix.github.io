﻿$(document).ready(function () {
    var viewModel = function () {
        console.log('ViewModel On')
        //Variables

        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/leagues';
        self.error = ko.observable();
        self.leagues = ko.observableArray([]);

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }
        ajaxHelper(baseUri, 'GET').done(function (data) {
            self.leagues(data);
        });



    };
    ko.applyBindings(new viewModel())
})
