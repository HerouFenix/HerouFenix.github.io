﻿$(document).ready(function () {
    var viewModel = function () {
        //Variables
        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/teams';
        self.teamName = ko.observable();
        self.searchTeam = ko.observableArray([]);
        self.error = ko.observable();

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            });
        };

        teamDel = function () {
            self.teamName("");
        };

        //Search Function
        teamSearch = function () {
            baseUri = 'http://192.168.160.28/football/api/teams/search?srcStr=' + self.teamName();
            $('#loader').removeClass('hidden');
            ajaxHelper(baseUri, 'GET').done(function (data) {
                console.log(JSON.stringify(data));
                self.searchTeam(data);
                $('#loader').addClass('hidden')
            });
        }

        //enter search
        $(document).keypress(function (key) {
            if (key.which == 13) {
                teamSearch();
            }
        });


    };
    ko.applyBindings(new viewModel)

})