﻿$(document).ready(function () {
    var viewModel = function () {
        console.log('ViewModel On')
        //Variables:

        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/players/';
        self.error = ko.observable();
        self.PlayerInfo = ko.observableArray([]);
        var doc = document.URL;
        doc = doc.split("/");
        console.log(doc);
        var playerId = doc[4];
        var playerId2 = doc[5];
        console.log(playerId)
        console.log(playerId2);

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        //Info Display

        baseUri = 'http://192.168.160.28/football/api/players/' + playerId;
        ajaxHelper(baseUri, 'GET').done(function (data) {
            console.log(JSON.stringify(data))
            //Name
            self.PlayerInfo(data)

            //Image
            $('#playerFace').attr('src', 'https://cdn.sofifa.org/18/players/' + playerId2 + '.png');

            //Id/Rating/Potential
            var playerClass = parseFloat(data.player_attributes[0].overall_rating);
            if (playerClass > 90) {
                $('#playerRating').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerRating').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerRating').addClass('label-warning')
                    }
                    else {
                        $('#playerRating').addClass('label-danger')
                    }
                }
            }
            $('#playerRating').html(data.player_attributes[0].overall_rating);


            var playerClass = parseFloat(data.player_attributes[0].overall_rating);
            if (playerClass > 90) {
                $('#playerPotential').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerPotential').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerPotential').addClass('label-warning')
                    }
                    else {
                        $('#playerPotential').addClass('label-danger')
                    }
                }
            }
            $('#playerPotential').html(data.player_attributes[0].potential);

            //General
            $('#playerBirthday').html(data.birthday.split('T')[0]);
            $('#playerHeight').html(((data.height))/100 + ' m');
            $('#playerWeight').html(((data.weight) * 0.45359237).toFixed(2) + ' Kg');
            $('#playerFoot').html(data.player_attributes[0].preferred_foot);
            $('#playerATKwr').html(data.player_attributes[0].attacking_work_rate);
            $('#playerDEFwr').html(data.player_attributes[0].defensive_work_rate);

            //Attributes


            //ATTACKING
            //Crossing
            var playerClass = parseFloat(data.player_attributes[0].crossing);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerCrossing').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerCrossing').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerCrossing').addClass('label-warning')
                    }
                    else {
                        $('#playerCrossing').addClass('label-danger')
                    }
                }
            }
            $('#playerCrossing').html(data.player_attributes[0].crossing);

            //Finishing
            var playerClass = parseFloat(data.player_attributes[0].finishing);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerFinishing').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerFinishing').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerFinishing').addClass('label-warning')
                    }
                    else {
                        $('#playerFinishing').addClass('label-danger')
                    }
                }
            }
            $('#playerFinishing').html(data.player_attributes[0].finishing);

            //Heading Accuracy
            var playerClass = parseFloat(data.player_attributes[0].heading_accuracy);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerHeadingAcc').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerHeadingAcc').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerHeadingAcc').addClass('label-warning')
                    }
                    else {
                        $('#playerHeadingAcc').addClass('label-danger')
                    }
                }
            }
            $('#playerHeadingAcc').html(data.player_attributes[0].heading_accuracy);

            //Short Passing
            var playerClass = parseFloat(data.player_attributes[0].short_passing);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerShortPass').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerShortPass').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerShortPass').addClass('label-warning')
                    }
                    else {
                        $('#playerShortPass').addClass('label-danger')
                    }
                }
            }
            $('#playerShortPass').html(data.player_attributes[0].short_passing);

            //Volley
            var playerClass = parseFloat(data.player_attributes[0].volleys);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerVolleys').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerVolleys').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerVolleys').addClass('label-warning')
                    }
                    else {
                        $('#playerVolleys').addClass('label-danger')
                    }
                }
            }
            $('#playerVolleys').html(data.player_attributes[0].volleys);

            //-----------------

            //SKILL
            //Dribbling
            var playerClass = parseFloat(data.player_attributes[0].dribbling);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerDribbling').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerDribbling').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerDribbling').addClass('label-warning')
                    }
                    else {
                        $('#playerDribbling').addClass('label-danger')
                    }
                }
            }
            $('#playerDribbling').html(data.player_attributes[0].dribbling);

            //Curve
            var playerClass = parseFloat(data.player_attributes[0].curve);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerCurve').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerCurve').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerCurve').addClass('label-warning')
                    }
                    else {
                        $('#playerCurve').addClass('label-danger')
                    }
                }
            }
            $('#playerCurve').html(data.player_attributes[0].curve);

            //free Kick Accuracy
            var playerClass = parseFloat(data.player_attributes[0].free_kick_accuracy);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerFreeKickAcc').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerFreeKickAcc').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerFreeKickAcc').addClass('label-warning')
                    }
                    else {
                        $('#playerFreeKickAcc').addClass('label-danger')
                    }
                }
            }
            $('#playerFreeKickAcc').html(data.player_attributes[0].free_kick_accuracy);

            //Long Passing
            var playerClass = parseFloat(data.player_attributes[0].long_passing);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerLongPassing').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerLongPassing').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerLongPassing').addClass('label-warning')
                    }
                    else {
                        $('#playerLongPassing').addClass('label-danger')
                    }
                }
            }
            $('#playerLongPassing').html(data.player_attributes[0].long_passing);

            //Ball Control
            var playerClass = parseFloat(data.player_attributes[0].ball_control);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerBallControl').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerBallControl').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerBallControl').addClass('label-warning')
                    }
                    else {
                        $('#playerBallControl').addClass('label-danger')
                    }
                }
            }
            $('#playerBallControl').html(data.player_attributes[0].ball_control);

            //------------

            //MOVEMENT
            //Acceleration
            var playerClass = parseFloat(data.player_attributes[0].acceleration);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerAcceleration').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerAcceleration').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerAcceleration').addClass('label-warning')
                    }
                    else {
                        $('#playerAcceleration').addClass('label-danger')
                    }
                }
            }
            $('#playerAcceleration').html(data.player_attributes[0].acceleration);

            //Sprint Speed
            var playerClass = parseFloat(data.player_attributes[0].sprint_speed);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerSprintSpeed').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerSprintSpeed').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerSprintSpeed').addClass('label-warning')
                    }
                    else {
                        $('#playerSprintSpeed').addClass('label-danger')
                    }
                }
            }
            $('#playerSprintSpeed').html(data.player_attributes[0].sprint_speed);

            //Agility
            var playerClass = parseFloat(data.player_attributes[0].agility);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerAgility').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerAgility').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerAgility').addClass('label-warning')
                    }
                    else {
                        $('#playerAgility').addClass('label-danger')
                    }
                }
            }
            $('#playerAgility').html(data.player_attributes[0].agility);

            //Reactions
            var playerClass = parseFloat(data.player_attributes[0].reactions);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerReactions').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerReactions').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerReactions').addClass('label-warning')
                    }
                    else {
                        $('#playerReactions').addClass('label-danger')
                    }
                }
            }
            $('#playerReactions').html(data.player_attributes[0].reactions);

            //Balance
            var playerClass = parseFloat(data.player_attributes[0].balance);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerBalance').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerBalance').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerBalance').addClass('label-warning')
                    }
                    else {
                        $('#playerBalance').addClass('label-danger')
                    }
                }
            }
            $('#playerBalance').html(data.player_attributes[0].balance);

            //-------------

            //POWER
            //Shot Power
            var playerClass = parseFloat(data.player_attributes[0].shot_power);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerShotPower').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerShotPower').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerShotPower').addClass('label-warning')
                    }
                    else {
                        $('#playerShotPower').addClass('label-danger')
                    }
                }
            }
            $('#playerShotPower').html(data.player_attributes[0].shot_power);

            //Jumping
            var playerClass = parseFloat(data.player_attributes[0].jumping);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerJumping').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerJumping').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerJumping').addClass('label-warning')
                    }
                    else {
                        $('#playerJumping').addClass('label-danger')
                    }
                }
            }
            $('#playerJumping').html(data.player_attributes[0].jumping);

            //Stamina
            var playerClass = parseFloat(data.player_attributes[0].stamina);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerStamina').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerStamina').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerStamina').addClass('label-warning')
                    }
                    else {
                        $('#playerStamina').addClass('label-danger')
                    }
                }
            }
            $('#playerStamina').html(data.player_attributes[0].stamina);


            //Strength
            var playerClass = parseFloat(data.player_attributes[0].strength);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerStrength').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerStrength').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerStrength').addClass('label-warning')
                    }
                    else {
                        $('#playerStrength').addClass('label-danger')
                    }
                }
            }
            $('#playerStrength').html(data.player_attributes[0].strength);

            //Long Shots
            var playerClass = parseFloat(data.player_attributes[0].long_shots);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerLongShots').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerLongShots').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerLongShots').addClass('label-warning')
                    }
                    else {
                        $('#playerLongShots').addClass('label-danger')
                    }
                }
            }
            $('#playerLongShots').html(data.player_attributes[0].long_shots);

            //----------------

            //----------------

            //MENTALITY
            //Aggression
            var playerClass = parseFloat(data.player_attributes[0].aggression);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerAggression').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerAggression').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerAggression').addClass('label-warning')
                    }
                    else {
                        $('#playerAggression').addClass('label-danger')
                    }
                }
            }
            $('#playerAggression').html(data.player_attributes[0].aggression);

            //Interceptions
            var playerClass = parseFloat(data.player_attributes[0].interceptions);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerInterceptions').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerInterceptions').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerInterceptions').addClass('label-warning')
                    }
                    else {
                        $('#playerInterceptions').addClass('label-danger')
                    }
                }
            }
            $('#playerInterceptions').html(data.player_attributes[0].interceptions);

            //Positioning
            var playerClass = parseFloat(data.player_attributes[0].positioning);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerPositioning').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerPositioning').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerPositioning').addClass('label-warning')
                    }
                    else {
                        $('#playerPositioning').addClass('label-danger')
                    }
                }
            }
            $('#playerPositioning').html(data.player_attributes[0].positioning);

            //Vision
            var playerClass = parseFloat(data.player_attributes[0].vision);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerVision').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerVision').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerVision').addClass('label-warning')
                    }
                    else {
                        $('#playerVision').addClass('label-danger')
                    }
                }
            }
            $('#playerVision').html(data.player_attributes[0].vision);

            //Penalties
            var playerClass = parseFloat(data.player_attributes[0].penalties);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerPenalties').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerPenalties').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerPenalties').addClass('label-warning')
                    }
                    else {
                        $('#playerPenalties').addClass('label-danger')
                    }
                }
            }
            $('#playerPenalties').html(data.player_attributes[0].penalties);

            //--------------

            //DEFENDING
            //DEFENDING
            //Marking
            var playerClass = parseFloat(data.player_attributes[0].marking);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerMarking').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerMarking').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerMarking').addClass('label-warning')
                    }
                    else {
                        $('#playerMarking').addClass('label-danger')
                    }
                }
            }
            $('#playerMarking').html(data.player_attributes[0].marking);

            //Standing Tackle
            var playerClass = parseFloat(data.player_attributes[0].standing_tackle);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerStandingTackle').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerStandingTackle').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerStandingTackle').addClass('label-warning')
                    }
                    else {
                        $('#playerStandingTackle').addClass('label-danger')
                    }
                }
            }
            $('#playerStandingTackle').html(data.player_attributes[0].standing_tackle);

            //Sliding Tackle
            var playerClass = parseFloat(data.player_attributes[0].sliding_tackle);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerSlidingTackle').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerSlidingTackle').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerSlidingTackle').addClass('label-warning')
                    }
                    else {
                        $('#playerSlidingTackle').addClass('label-danger')
                    }
                }
            }
            $('#playerSlidingTackle').html(data.player_attributes[0].sliding_tackle);


            //-------------------------

            //GOALKEEPING
            //GK Diving
            //GK Diving
            var playerClass = parseFloat(data.player_attributes[0].gk_diving);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerGkDiving').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerGkDiving').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerGkDiving').addClass('label-warning')
                    }
                    else {
                        $('#playerGkDiving').addClass('label-danger')
                    }
                }
            }
            $('#playerGkDiving').html(data.player_attributes[0].gk_diving);

            //GK Handling
            var playerClass = parseFloat(data.player_attributes[0].gk_handling);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerGkHandling').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerGkHandling').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerGkHandling').addClass('label-warning')
                    }
                    else {
                        $('#playerGkHandling').addClass('label-danger')
                    }
                }
            }
            $('#playerGkHandling').html(data.player_attributes[0].gk_handling);

            //GK Kicking
            var playerClass = parseFloat(data.player_attributes[0].gk_kicking);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerGkKicking').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerGkKicking').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerGkKicking').addClass('label-warning')
                    }
                    else {
                        $('#playerGkKicking').addClass('label-danger')
                    }
                }
            }
            $('#playerGkKicking').html(data.player_attributes[0].gk_kicking);

            //GK Positioning
            var playerClass = parseFloat(data.player_attributes[0].gk_positioning);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerGkPositioning').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerGkPositioning').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerGkPositioning').addClass('label-warning')
                    }
                    else {
                        $('#playerGkPositioning').addClass('label-danger')
                    }
                }
            }
            $('#playerGkPositioning').html(data.player_attributes[0].gk_positioning);

            //GK Reflexes
            var playerClass = parseFloat(data.player_attributes[0].gk_reflexes);
            console.log(playerClass)
            if (playerClass > 90) {
                $('#playerGkReflexes').addClass('label-primary');
            } else {
                if (playerClass > 70) {
                    $('#playerGkReflexes').addClass('label-success')
                }
                else {
                    if (playerClass > 50) {
                        $('#playerGkReflexes').addClass('label-warning')
                    }
                    else {
                        $('#playerGkReflexes').addClass('label-danger')
                    }
                }
            }
            $('#playerGkReflexes').html(data.player_attributes[0].gk_reflexes);

        });
            
        //Go Back
        goBack = function () {
            window.location.replace('Players.html');
        }



    };
    ko.applyBindings(new viewModel())
})
