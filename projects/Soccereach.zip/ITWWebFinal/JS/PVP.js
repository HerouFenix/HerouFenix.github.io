﻿$(document).ready(function () {
    var viewModel = function () {
        //Variables:
        var self = this;
        var self = this;
        var baseUri = '';
        self.playerName1 = ko.observable();
        self.playerName2 = ko.observable();
        self.showAttributesValue = ko.observable(false);
        self.searchPlayer1 = ko.observableArray([]);
        self.searchPlayer2 = ko.observableArray([]);
        self.playerOne = ko.observableArray([]);
        self.playerTwo = ko.observableArray([]);


        self.error = ko.observable();

        
        //Functions:
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        playerDel1 = function () {
            self.playerName1("")
        };
        playerDel2 = function () {
            self.playerName2("")
        };

        playerSearch1 = function () {
            if (!($('#playerName1').val() == '')) {
                baseUri = 'http://192.168.160.28/football/api/players/search?srcStr=' + self.playerName1();
                $('#loader1').removeClass('hidden');
                ajaxHelper(baseUri, 'GET').done(function (data) {
                    $('#select1').removeClass('hidden')
                    $('#loader1').addClass('hidden');
                    self.searchPlayer1(data);
                    console.log(data)
                });
            }  
        };
        playerSearch2 = function () {
            if (!($('#playerName2').val() == '')) {
                baseUri = 'http://192.168.160.28/football/api/players/search?srcStr=' + self.playerName2();
                $('#loader2').removeClass('hidden');
                ajaxHelper(baseUri, 'GET').done(function (data) {
                    $('#select2').removeClass('hidden')
                    $('#loader2').addClass('hidden');
                    self.searchPlayer2(data);
                    console.log(data)
                });
            }
        };

        showAttributes = function () {
            if (($('#select1').val() == '') || ($('#select2').val() == '')) {
                $("#initiate").removeClass('hidden')
            }
            else {
                $("#initiate").addClass('hidden')
                self.showAttributesValue(true);
                console.log($('#select1').val())
                baseUri = 'http://192.168.160.28/football/api/players/' + $('#select1').val();
                ajaxHelper(baseUri, 'GET').done(function (data) {
                    console.log(JSON.stringify(data));
                    self.playerOne(data)


                });
                console.log($('#select2').val())
                baseUri = 'http://192.168.160.28/football/api/players/' + $('#select2').val();
                ajaxHelper(baseUri, 'GET').done(function (data) {
                    console.log(JSON.stringify(data));
                    self.playerTwo(data)
                });
            };
        };

        $('#playerName1').keypress(function (key) {
            if (key.which == 13) {
                playerSearch1();
            }
        });

        $('#playerName2').keypress(function (key) {
            if (key.which == 13) {
                playerSearch2();
            }
        });
    };
    ko.applyBindings(new viewModel);


})