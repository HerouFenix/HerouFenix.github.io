﻿$(document).ready(function () {
    var viewModel = function () {
        console.log('ViewModel On')
        //Variables:

        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/teams/';
        self.error = ko.observable();
        self.leagueBasics = ko.observableArray([]);
        var doc = document.URL;
        doc = doc.split("/");
        console.log(doc);
        var leagueId = doc[4];
        console.log(leagueId);

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        //Info Display

        baseUri = 'http://192.168.160.28/football/api/leagues/' + leagueId;
        ajaxHelper(baseUri, 'GET').done(function (data) {
            console.log("working");
            console.log(JSON.stringify(data));
            //Name/ID/Acronym/Country (BASICS)
            self.leagueBasics(data);
        });
            //Image


        //Go Back
        goBack = function () {
            window.location.replace('Leagues.html');
        }
    }
    ko.applyBindings(new viewModel);
});