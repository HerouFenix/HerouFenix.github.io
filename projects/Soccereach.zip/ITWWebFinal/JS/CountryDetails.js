﻿$(document).ready(function () {
    var viewModel = function () {
        console.log('ViewModel On')
        //Variables:

        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/countries/';
        self.error = ko.observable();
        self.countryBasics = ko.observableArray([]);
        self.countryLeagues = ko.observableArray([]);
        self.countryInfo = ko.observableArray([]);
        self.capital = ko.observable();
        self.Temp = ko.observable();
        self.Weather = ko.observable();
        self.Coordinates = ko.observable();
        var doc = document.URL;
        doc = doc.split("/");
        console.log(doc);
        var countryId = doc[4];
        console.log(countryId);

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        //Info Display

        baseUri = 'http://192.168.160.28/football/api/countries/' + countryId;
        ajaxHelper(baseUri, 'GET').done(function (data) {
            console.log("working");
            console.log(JSON.stringify(data));

            //Name/ID/Acronym/Country (BASICS)
            self.countryBasics(data);
            var country = data.name
            console.log(country)
            var capital = ''
            //Other Info
            switch (country) {
                case 'Belgium':
                    capital = 'brussels, be';
                    break;
                case 'England':
                    capital = 'london, uk';
                    break;
                case 'France':
                    capital = 'paris, fr';
                    break;
                case 'Germany':
                    capital = 'berlin, de';
                    break;
                case 'Italy':
                    capital = 'rome, it';
                    break;
                case 'Netherlands':
                    capital = 'Amsterdam, nl';
                    break;
                case 'Poland':
                    capital = 'Warsaw, pl';
                    break;
                case 'Portugal':
                    capital = 'Lisbon, pt';
                    break;
                case 'Scotland':
                    capital = 'edinburgh, uk';
                    break;
                case 'Spain':
                    capital = 'madrid, es';
                    break;
                case 'Switzerland':
                    capital = 'bern, ch';
                    break;
            }
            console.log(capital)
            $.ajax({
                url: "http://api.openweathermap.org/data/2.5/weather",
                data: {
                    q: capital,
                    APPID: 'b2b1df463182c3cca5276e9d3267cc95'
                },
                success: function (data) {
                    console.log(data)
                    $('#Temp').html('Temperature - ' + (data.main.temp - 273.15).toFixed(2).toString() + 'ºC');
                    $('#Weather').html('Weather - ' +data.weather[0].description);
                    $('#Coordinates').html('Coordinates - Lon (º): ' + data.coord.lon + ' Lat (º): ' + data.coord.lat);
                    $('#Capital').html('Capital - ' +data.name);
                    $('#loader').addClass('hidden')
                    $('#labelLoader').addClass('hidden')
                },
                error: function(){
                    console.log('fail')
                }
            })
        });

        var leaguesUri = 'http://192.168.160.28/football/api/countries/countryLeagues/' + countryId;
        ajaxHelper(leaguesUri, 'GET').done(function (data) {
            console.log("working");
            console.log(JSON.stringify(data));

            //Name/ID/Acronym/Country (BASICS)
            self.countryLeagues(data);
        });
        //Image


        //Go Back
        goBack = function () {
            window.location.replace('Countries.html');
        }
    }
    ko.applyBindings(new viewModel);
});