﻿$(document).ready(function () {
    var viewModel = function () {
        //Variables:
        var self = this;
        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/players';
        self.playerName = ko.observable();
        self.searchPlayer = ko.observableArray([]);
        self.error = ko.observable();

        //Functions:
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        playerDel = function () {
            self.playerName("")
        };

        //Search Function
        playerSearch = function () {
            baseUri = 'http://192.168.160.28/football/api/players/search?srcStr=' + self.playerName();
            $('#loader').removeClass('hidden');
            ajaxHelper(baseUri, 'GET').done(function (data) {
                self.searchPlayer(data);
                $('#loader').addClass('hidden')
            })
        };

        //enter search
        $(document).keypress(function (key) {
            if (key.which == 13) {
                playerSearch();
            }
        });
    };
    ko.applyBindings(new viewModel);
});