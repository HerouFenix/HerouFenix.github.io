﻿$(document).ready(function () {
    var viewModel = function () {
        console.log('ViewModel On')
        //Variables:

        var self = this;
        var baseUri = 'http://192.168.160.28/football/api/teams/';
        self.error = ko.observable();
        self.teamBasics = ko.observableArray();
        self.teamPhoto = ko.observable();
        self.teamSeasons = ko.observableArray();
        self.teamMatches = ko.observableArray();
        self.teamMatch = ko.observableArray();
        self.team = ko.observable();
        var doc = document.URL;
        doc = doc.split("/");
        console.log(doc);
        var teamId = doc[4];
        var teamId2 = doc[5];
        self.matchData = ko.observableArray([])
        console.log(teamId);
        console.log(teamId2);

        //Functions
        function ajaxHelper(uri, method, data) {
            self.error(''); // Clear error message
            return $.ajax({
                type: method,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("AJAX Call[" + uri + "] Fail...");
                    self.error(errorThrown);
                }
            })
        }

        //Info Display

        baseUri = 'http://192.168.160.28/football/api/teams/' + teamId;
        ajaxHelper(baseUri, 'GET').done(function (data) {
            console.log("working");
            console.log(JSON.stringify(data));
            //Name/ID/Acronym/Country (BASICS)
            self.teamBasics(data);
            var working = self.teamBasics();

            //Image
            self.teamPhoto("https://cdn.sofifa.org/18/teams/" + teamId2 + ".png");
        });

        //Seasons/KITS
        var seasonUri = 'http://192.168.160.28/football/api/teams/seasons/' + teamId;
        ajaxHelper(seasonUri, 'GET').done(function (data, teamId2) {
            season = data;
            console.log(season);
            self.teamSeasons(season);
            var doc = document.URL;
            doc = doc.split("/");
            var teamId2 = doc[5];
            self.team(teamId2);
            var Match = season[0].Matches;
            self.teamMatches(Match);

        });

        //Match Info
        matchInfo = function () {
            console.log(this.id + "WOOOOW")
            var matchUri = 'http://192.168.160.28/football/api/matches/' + this.id;
            ajaxHelper(matchUri, 'GET').done(function (data) {
                console.log(data);
                self.teamMatch(data);
                console.log(data.Home_player[0].CSSClass)

            });


        };



        //Go Back
        goBack = function () {
            window.location.replace('Teams.html');
        }
    };
    ko.applyBindings(new viewModel())
})
