http://gonutri.bitballoon.com/
//PROTOTIPO FUNCIONAL FINAL



////////////////OTHERS///////////////

https://gonutri.000webhostapp.com/
//Microsite

https://prezi.com/view/REq3vuUo1nFh8WlvqdpZ/
//Prezi da apresenta��o final


//Nota:
Caso o bitballoon, por alguma raz�o inesperada n�o esteja online, tenho tamb�m o site colocado num backup server:
https://webgonutri.000webhostapp.com/

Este link n�o � suposto ser o considerado para avalia��o e funcionar� puramente como um backup