create index idxtournment on GamesDB.Tournments (GameID)

-- falar sobre os indexs criados para os nomes atraves do unique, nos outros atributosd de filtracao o sql server ou ia buscar e ficava mais lento ou entao nao ia buscar de todo