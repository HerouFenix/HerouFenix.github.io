INSERT INTO GamesDB.[Releases] VALUES ( 1, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 1, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 1, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 1, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 1, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 1, 6 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 2, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 2, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 2, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 3, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 3, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 3, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 3, 8 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 3, 9 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 4, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 4, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 4, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 4, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 4, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 5, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 6, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 7, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 7, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 7, 6 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 8, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 8, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 9, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 9, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 9, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 10, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 11, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 11, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 11, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 12, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 12, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 12, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 13, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 13, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 13, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 14, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 14, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 14, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 14, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 15, 13 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 15, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 15, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 16, 13 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 16, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 17, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 18, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 18, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 18, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 19, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 20, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 21, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 22, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 22, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 23, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 23, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 24, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 24, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 25, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 25, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 26, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 27, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 27, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 27, 8 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 27, 15 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 16 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 17 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 18 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 28, 19 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 29, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 29, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 29, 18 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 29, 17 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 30, 17 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 31, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 31, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 31, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 31, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 31, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 32, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 32, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 32, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 32, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 32, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 33, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 33, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 33, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 33, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 34, 20 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 34, 21 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 34, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 34, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 34, 15 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 35, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 35, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 36, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 36, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 37, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 37, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 37, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 38, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 38, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 38, 23 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 39, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 39, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 39, 23 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 40, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 40, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 41, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 42, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 42, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 42, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 43, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 44, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 45, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 45, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 45, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 45, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 45, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 24 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 46, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 24 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 47, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 48, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 48, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 48, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 48, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 48, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 49, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 49, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 49, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 50, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 50, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 50, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 51, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 51, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 51, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 52, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 52, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 52, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 52, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 52, 25 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 53, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 53, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 53, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 53, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 53, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 54, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 55, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 56, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 56, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 56, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 56, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 56, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 57, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 57, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 57, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 57, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 57, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 58, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 59, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 60, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 60, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 60, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 61, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 61, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 61, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 61, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 61, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 62, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 63, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 64, 25 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 65, 26 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 66, 26 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 67, 19 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 68, 17 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 69, 8 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 70, 24 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 70, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 71, 9 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 72, 24 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 73, 24 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 73, 26 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 74, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 74, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 75, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 76, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 18 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 21 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 8 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 77, 27 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 78, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 78, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 78, 18 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 13 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 79, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 13 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 80, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 22 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 13 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 81, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 82, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 82, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 82, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 83, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 83, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 83, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 83, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 83, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 84, 25 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 85, 25 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 85, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 85, 27 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 85, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 85, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 25 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 8 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 27 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 86, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 87, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 87, 27 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 88, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 88, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 88, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 88, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 89, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 89, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 89, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 89, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 14 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 11 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 12 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 10 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 90, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 91, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 91, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 91, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 92, 21 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 92, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 92, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 93, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 93, 2 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 94, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 94, 3 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 94, 5 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 95, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 95, 7 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 95, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 96, 1 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 96, 4 )
GO
INSERT INTO GamesDB.[Releases] VALUES ( 96, 7 )
GO