INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 1, 1 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 3, 2 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 7, 3 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 8, 4 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 9, 5 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 10, 6 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 12, 7 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 13, 8 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 15, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 16, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 17, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 18, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 19, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 20, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 21, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 22, 9 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 23, 10 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 24, 10 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 25, 10 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 26, 10 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 27, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 28, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 29, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 30, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 31, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 32, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 33, 11 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 34, 12 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 35, 12 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 36, 12 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 37, 12 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 38, 13 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 39, 13 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 40, 13 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 41, 13 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 42, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 43, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 44, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 45, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 46, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 47, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 48, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 49, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 50, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 51, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 52, 14 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 53, 15 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 54, 15 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 55, 15 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 56, 15 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 57, 15 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 58, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 59, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 60, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 61, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 62, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 63, 16 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 64, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 65, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 66, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 67, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 68, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 69, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 70, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 71, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 72, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 73, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 74, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 75, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 76, 17 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 77, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 78, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 79, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 80, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 81, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 82, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 83, 18 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 84, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 85, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 86, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 87, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 88, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 89, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 90, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 91, 19 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 92, 20 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 93, 20 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 94, 20 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 95, 20 )
GO
INSERT INTO GamesDB.[GameBelongsFranchise] VALUES ( 96, 20 )
GO