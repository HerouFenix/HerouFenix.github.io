INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 1 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 1 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 2 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 2 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 25, 3 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 3, 4 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 5 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 33, 5 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 34, 6 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 23, 7 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 3, 8 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 3, 9 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 3, 10 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 11 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 11 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 12 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 12 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 13 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 13 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 3, 14 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 15 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32 , 15 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 16 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 16 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 17 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 17 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 22, 18 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 19 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 19 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 20 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 20 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 21 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 32, 21 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 22, 22 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 14, 23 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 14, 24 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 14, 25 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 14, 26 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 8, 27 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 8, 28 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 8, 29 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 8, 30 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 30 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 24, 30 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 24, 31 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 31 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 24, 32 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 2, 32 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 14, 32 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 8, 33 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 25, 34 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 25, 35 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 25, 36 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 25, 37 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 38 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 39 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 40 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 41 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 42 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 42 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 43 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 43 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 44 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 44 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 45 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 45 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 46 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 46 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 47 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 47 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 48 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 48 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 49 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 49 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 50 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 50 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 51 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 51 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 5, 52 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 52 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 53 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 54 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 55 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 56 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 57 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 58 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 59 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 60 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 61 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 62 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 28, 63 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 64 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 65 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 66 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 67 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 68 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 68 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 69 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 70 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 71 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 72 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 73 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 36, 74 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 75 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 75 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 1, 76 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 77 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 78 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 79 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 80 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 81 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 82 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 35, 83 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 84 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 85 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 86 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 87 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 88 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 89 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 90 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 91 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 92 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 93 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 94 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 95 )
GO
INSERT INTO GamesDB.[GameGenre] VALUES ( 37, 96 )
GO