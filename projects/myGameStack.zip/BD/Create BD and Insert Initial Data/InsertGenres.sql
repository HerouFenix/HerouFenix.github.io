INSERT INTO GamesDB.[Genres] VALUES ( 'Platformer' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Shooter' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Fighting' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Beat em up' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Stealth' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Survival' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Rythm' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Survival Horror' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Metroidvania' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Text Adventure' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Visual Novel' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Graphic Adventure' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Interactive Movie' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Action RPG' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'JRPG' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'MMORPG' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Roguelike' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Sandbox RPG' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Life Simulator' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Vehicle Simulator' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Tycoon' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Real Time Strategy (RTS)' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Multiplayer Online Battle Arena (MOBA)' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Tower Defense' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Racing' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Turn Based Strategy (TBS)' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Sports Game' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'MMO' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Casual' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Party' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Trivia' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'First Person' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Third Person' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Card Game' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Action Adventure' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Auto Running' )
GO
INSERT INTO GamesDB.[Genres] VALUES ( 'Action Role-Playing' )
GO