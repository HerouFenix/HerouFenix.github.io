INSERT INTO GamesDB.[Events] VALUES ( 'virginiaSmith', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'virginiaSmith', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'virginiaSmith', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'virginiaSmith', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'virginiaSmith', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJohnson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJohnson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJohnson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJohnson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJohnson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'philWilliams', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'philWilliams', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'philWilliams', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'philWilliams', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'philWilliams', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meghnaBrown', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meghnaBrown', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meghnaBrown', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meghnaBrown', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meghnaBrown', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaJones', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaJones', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaJones', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaJones', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaJones', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deborahMiller', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deborahMiller', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deborahMiller', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deborahMiller', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deborahMiller', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDavis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDavis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDavis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDavis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDavis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynGarcia', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynGarcia', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynGarcia', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynGarcia', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynGarcia', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samiRodriguez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samiRodriguez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samiRodriguez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samiRodriguez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samiRodriguez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'damonWilson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'damonWilson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'damonWilson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'damonWilson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'damonWilson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoMartinez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoMartinez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoMartinez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoMartinez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoMartinez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaAnderson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaAnderson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaAnderson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaAnderson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaAnderson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganTaylor', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganTaylor', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganTaylor', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganTaylor', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganTaylor', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgiaThomas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgiaThomas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgiaThomas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgiaThomas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgiaThomas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyHernandez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyHernandez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyHernandez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyHernandez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyHernandez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneMoore', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneMoore', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneMoore', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneMoore', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneMoore', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaMartin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaMartin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaMartin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaMartin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaMartin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganJackson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganJackson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganJackson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganJackson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'meganJackson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieThompson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieThompson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieThompson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieThompson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieThompson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWhite', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWhite', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWhite', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWhite', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWhite', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedLopez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedLopez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedLopez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedLopez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedLopez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carljudyLee', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carljudyLee', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carljudyLee', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carljudyLee', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carljudyLee', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneGonzalez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneGonzalez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneGonzalez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneGonzalez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'duaneGonzalez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jesusHarris', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jesusHarris', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jesusHarris', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jesusHarris', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jesusHarris', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coletteClark', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coletteClark', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coletteClark', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coletteClark', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coletteClark', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferLewis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferLewis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferLewis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferLewis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferLewis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethRobinson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethRobinson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethRobinson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethRobinson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethRobinson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joneWalker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joneWalker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joneWalker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joneWalker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joneWalker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danPerez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danPerez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danPerez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danPerez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danPerez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisYoung', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisYoung', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisYoung', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisYoung', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisYoung', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nelsonmarleneAllen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nelsonmarleneAllen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nelsonmarleneAllen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nelsonmarleneAllen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nelsonmarleneAllen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'crystalSanchez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'crystalSanchez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'crystalSanchez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'crystalSanchez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'crystalSanchez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWright', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWright', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWright', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWright', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'barrieWright', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanneKing', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanneKing', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanneKing', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanneKing', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanneKing', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'genaleonScott', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'genaleonScott', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'genaleonScott', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'genaleonScott', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'genaleonScott', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jimGreen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jimGreen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jimGreen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jimGreen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jimGreen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietBaker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietBaker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietBaker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietBaker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietBaker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietAdams', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietAdams', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietAdams', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietAdams', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietAdams', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynNelson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynNelson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynNelson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynNelson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marilynNelson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rosaHill', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rosaHill', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rosaHill', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rosaHill', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rosaHill', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellyRamirez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellyRamirez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellyRamirez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellyRamirez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellyRamirez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'douglasCampbell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'douglasCampbell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'douglasCampbell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'douglasCampbell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'douglasCampbell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedMitchell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedMitchell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedMitchell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedMitchell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedMitchell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjRoberts', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjRoberts', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjRoberts', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjRoberts', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjRoberts', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leliaCarter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leliaCarter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leliaCarter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leliaCarter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leliaCarter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferPhillips', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferPhillips', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferPhillips', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferPhillips', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferPhillips', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaEvans', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaEvans', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaEvans', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaEvans', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaEvans', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaTurner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaTurner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaTurner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaTurner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaTurner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedTorres', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedTorres', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedTorres', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedTorres', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohamedTorres', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffParker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffParker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffParker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffParker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffParker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellawillCollins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellawillCollins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellawillCollins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellawillCollins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellawillCollins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjEdwards', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjEdwards', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjEdwards', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjEdwards', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fjEdwards', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossannaStewart', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossannaStewart', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossannaStewart', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossannaStewart', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossannaStewart', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'poppyFlores', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'poppyFlores', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'poppyFlores', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'poppyFlores', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'poppyFlores', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraMorris', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraMorris', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraMorris', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraMorris', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraMorris', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaNguyen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaNguyen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaNguyen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaNguyen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaNguyen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinMurphy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinMurphy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinMurphy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinMurphy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinMurphy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRivera', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRivera', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRivera', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRivera', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRivera', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sidneyCook', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sidneyCook', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sidneyCook', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sidneyCook', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sidneyCook', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethRogers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethRogers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethRogers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethRogers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethRogers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evelynMorgan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evelynMorgan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evelynMorgan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evelynMorgan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evelynMorgan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanPeterson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanPeterson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanPeterson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanPeterson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanPeterson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danCooper', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danCooper', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danCooper', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danCooper', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danCooper', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnReed', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnReed', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnReed', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnReed', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnReed', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamBailey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamBailey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamBailey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamBailey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamBailey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyBell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyBell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyBell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyBell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyBell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyGomez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyGomez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyGomez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyGomez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyGomez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertKelly', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertKelly', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertKelly', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertKelly', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertKelly', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianeHoward', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianeHoward', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianeHoward', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianeHoward', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianeHoward', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinWard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinWard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinWard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinWard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinWard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisCox', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisCox', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisCox', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisCox', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisCox', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidDiaz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidDiaz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidDiaz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidDiaz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidDiaz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraRichardson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraRichardson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraRichardson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraRichardson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraRichardson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'siqiWood', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'siqiWood', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'siqiWood', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'siqiWood', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'siqiWood', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionWatson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionWatson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionWatson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionWatson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionWatson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillBrooks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillBrooks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillBrooks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillBrooks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillBrooks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBennett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBennett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBennett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBennett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBennett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'markGray', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'markGray', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'markGray', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'markGray', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'markGray', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noraJames', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noraJames', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noraJames', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noraJames', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noraJames', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margoReyes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margoReyes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margoReyes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margoReyes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margoReyes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cezanneCruz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cezanneCruz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cezanneCruz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cezanneCruz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cezanneCruz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretHughes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretHughes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretHughes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretHughes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretHughes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyPrice', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyPrice', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyPrice', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyPrice', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyPrice', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anaMyers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anaMyers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anaMyers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anaMyers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anaMyers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisonshawnLong', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisonshawnLong', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisonshawnLong', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisonshawnLong', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisonshawnLong', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyFoster', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyFoster', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyFoster', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyFoster', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyFoster', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coraSanders', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coraSanders', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coraSanders', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coraSanders', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coraSanders', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRoss', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRoss', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRoss', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRoss', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRoss', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMorales', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMorales', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMorales', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMorales', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMorales', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattayaPowell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattayaPowell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattayaPowell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattayaPowell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattayaPowell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'luciaSullivan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'luciaSullivan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'luciaSullivan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'luciaSullivan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'luciaSullivan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderRussell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderRussell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderRussell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderRussell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderRussell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'wilkeOrtiz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'wilkeOrtiz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'wilkeOrtiz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'wilkeOrtiz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'wilkeOrtiz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mosheJenkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mosheJenkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mosheJenkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mosheJenkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mosheJenkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeanaGutierrez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeanaGutierrez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeanaGutierrez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeanaGutierrez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeanaGutierrez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorPerry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorPerry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorPerry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorPerry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorPerry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderButler', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderButler', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderButler', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderButler', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderButler', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredBarnes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredBarnes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredBarnes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredBarnes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredBarnes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinFisher', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinFisher', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinFisher', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinFisher', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinFisher', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'litaHenderson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'litaHenderson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'litaHenderson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'litaHenderson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'litaHenderson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'phyllisColeman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'phyllisColeman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'phyllisColeman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'phyllisColeman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'phyllisColeman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamSimmons', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamSimmons', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamSimmons', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamSimmons', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamSimmons', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monroePatterson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monroePatterson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monroePatterson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monroePatterson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monroePatterson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karenJordan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karenJordan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karenJordan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karenJordan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karenJordan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilReynolds', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilReynolds', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilReynolds', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilReynolds', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilReynolds', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eileenHamilton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eileenHamilton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eileenHamilton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eileenHamilton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eileenHamilton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacGraham', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacGraham', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacGraham', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacGraham', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacGraham', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karinKim', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karinKim', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karinKim', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karinKim', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karinKim', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahGonzales', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahGonzales', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahGonzales', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahGonzales', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahGonzales', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leoAlexander', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leoAlexander', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leoAlexander', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leoAlexander', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leoAlexander', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katiejoeRamos', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katiejoeRamos', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katiejoeRamos', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katiejoeRamos', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katiejoeRamos', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineWallace', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineWallace', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineWallace', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineWallace', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineWallace', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lillieGriffin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lillieGriffin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lillieGriffin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lillieGriffin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lillieGriffin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bruceWest', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bruceWest', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bruceWest', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bruceWest', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bruceWest', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahCole', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahCole', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahCole', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahCole', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahCole', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadHayes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadHayes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadHayes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadHayes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadHayes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffChavez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffChavez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffChavez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffChavez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffChavez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraGibson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraGibson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraGibson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraGibson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraGibson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lynneBryant', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lynneBryant', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lynneBryant', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lynneBryant', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lynneBryant', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertoEllis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertoEllis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertoEllis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertoEllis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertoEllis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyStevens', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyStevens', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyStevens', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyStevens', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyStevens', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaMurray', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaMurray', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaMurray', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaMurray', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaMurray', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaFord', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaFord', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaFord', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaFord', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaFord', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMarshall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMarshall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMarshall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMarshall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMarshall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katieOwens', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katieOwens', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katieOwens', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katieOwens', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katieOwens', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamMcdonald', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamMcdonald', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamMcdonald', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamMcdonald', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamMcdonald', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'balintHarrison', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'balintHarrison', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'balintHarrison', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'balintHarrison', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'balintHarrison', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRuiz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRuiz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRuiz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRuiz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyRuiz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sybilKennedy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sybilKennedy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sybilKennedy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sybilKennedy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sybilKennedy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWells', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWells', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWells', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWells', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWells', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'l&bAlvarez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'l&bAlvarez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'l&bAlvarez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'l&bAlvarez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'l&bAlvarez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewWoods', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewWoods', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewWoods', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewWoods', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewWoods', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erinMendoza', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erinMendoza', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erinMendoza', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erinMendoza', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erinMendoza', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'patrickCastillo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'patrickCastillo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'patrickCastillo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'patrickCastillo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'patrickCastillo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaOlson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaOlson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaOlson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaOlson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaOlson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamWebb', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamWebb', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamWebb', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamWebb', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamWebb', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosWashington', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosWashington', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosWashington', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosWashington', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosWashington', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailTucker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailTucker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailTucker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailTucker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailTucker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacobFreeman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacobFreeman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacobFreeman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacobFreeman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacobFreeman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyBurns', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyBurns', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyBurns', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyBurns', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyBurns', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraHenry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraHenry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraHenry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraHenry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veraHenry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianVasquez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianVasquez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianVasquez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianVasquez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianVasquez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshSnyder', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshSnyder', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshSnyder', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshSnyder', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshSnyder', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamSimpson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamSimpson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamSimpson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamSimpson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamSimpson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshCrawford', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshCrawford', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshCrawford', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshCrawford', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshCrawford', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJimenez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJimenez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJimenez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJimenez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaJimenez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPorter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPorter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPorter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPorter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPorter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlindanMason', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlindanMason', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlindanMason', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlindanMason', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlindanMason', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaShaw', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaShaw', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaShaw', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaShaw', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaShaw', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonGordon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonGordon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonGordon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonGordon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonGordon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zackWagner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zackWagner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zackWagner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zackWagner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zackWagner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianHunter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianHunter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianHunter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianHunter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianHunter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edwardRomero', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edwardRomero', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edwardRomero', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edwardRomero', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edwardRomero', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHicks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHicks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHicks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHicks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHicks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaDixon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaDixon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaDixon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaDixon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaDixon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'diegoHunt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'diegoHunt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'diegoHunt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'diegoHunt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'diegoHunt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonPalmer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonPalmer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonPalmer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonPalmer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonPalmer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anyaRobertson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anyaRobertson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anyaRobertson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anyaRobertson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anyaRobertson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanBlack', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanBlack', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanBlack', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanBlack', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanBlack', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristenHolmes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristenHolmes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristenHolmes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristenHolmes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristenHolmes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineStone', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineStone', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineStone', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineStone', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catherineStone', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretMeyer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretMeyer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretMeyer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretMeyer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretMeyer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaBoyd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaBoyd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaBoyd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaBoyd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaBoyd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caraMills', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caraMills', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caraMills', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caraMills', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caraMills', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rayWarren', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rayWarren', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rayWarren', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rayWarren', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rayWarren', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gordonalexandraFox', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gordonalexandraFox', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gordonalexandraFox', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gordonalexandraFox', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gordonalexandraFox', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaRose', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaRose', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaRose', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaRose', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaRose', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'darRice', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'darRice', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'darRice', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'darRice', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'darRice', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMoreno', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMoreno', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMoreno', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMoreno', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMoreno', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriSchmidt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriSchmidt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriSchmidt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriSchmidt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriSchmidt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizaPatel', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizaPatel', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizaPatel', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizaPatel', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizaPatel', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rolvixFerguson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rolvixFerguson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rolvixFerguson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rolvixFerguson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rolvixFerguson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'manuelNichols', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'manuelNichols', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'manuelNichols', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'manuelNichols', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'manuelNichols', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHerrera', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHerrera', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHerrera', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHerrera', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHerrera', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeMedina', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeMedina', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeMedina', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeMedina', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeMedina', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanRyan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanRyan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanRyan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanRyan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jordanRyan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pennyFernandez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pennyFernandez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pennyFernandez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pennyFernandez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pennyFernandez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinWeaver', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinWeaver', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinWeaver', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinWeaver', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinWeaver', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaDaniels', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaDaniels', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaDaniels', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaDaniels', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaDaniels', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susieStephens', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susieStephens', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susieStephens', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susieStephens', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susieStephens', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'perryGardner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'perryGardner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'perryGardner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'perryGardner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'perryGardner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heribertoPayne', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heribertoPayne', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heribertoPayne', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heribertoPayne', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heribertoPayne', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewKelley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewKelley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewKelley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewKelley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewKelley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'careyDunn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'careyDunn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'careyDunn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'careyDunn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'careyDunn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlPierce', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlPierce', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlPierce', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlPierce', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlPierce', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelArnold', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelArnold', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelArnold', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelArnold', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelArnold', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterTran', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterTran', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterTran', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterTran', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterTran', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leahSpencer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leahSpencer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leahSpencer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leahSpencer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leahSpencer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alicePeters', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alicePeters', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alicePeters', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alicePeters', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alicePeters', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamHawkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamHawkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamHawkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamHawkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'miriamHawkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaGrant', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaGrant', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaGrant', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaGrant', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaGrant', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonHansen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonHansen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonHansen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonHansen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonHansen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulCastro', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulCastro', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulCastro', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulCastro', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulCastro', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brookeHoffman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brookeHoffman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brookeHoffman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brookeHoffman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brookeHoffman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHart', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHart', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHart', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHart', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaHart', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaElliott', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaElliott', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaElliott', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaElliott', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaElliott', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilCunningham', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilCunningham', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilCunningham', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilCunningham', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilCunningham', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomKnight', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomKnight', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomKnight', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomKnight', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomKnight', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonasBradley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonasBradley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonasBradley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonasBradley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonasBradley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosCarroll', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosCarroll', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosCarroll', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosCarroll', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosCarroll', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaHudson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaHudson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaHudson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaHudson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alishyaHudson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattijavierDuncan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattijavierDuncan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattijavierDuncan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattijavierDuncan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattijavierDuncan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraArmstrong', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraArmstrong', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraArmstrong', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraArmstrong', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraArmstrong', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlBerry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlBerry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlBerry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlBerry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilycarlBerry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionAndrews', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionAndrews', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionAndrews', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionAndrews', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orionAndrews', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaJohnston', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaJohnston', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaJohnston', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaJohnston', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaJohnston', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisLane', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisLane', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisLane', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisLane', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisLane', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'charlesRiley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'charlesRiley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'charlesRiley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'charlesRiley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'charlesRiley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianCarpenter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianCarpenter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianCarpenter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianCarpenter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianCarpenter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPerkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPerkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPerkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPerkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahPerkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catlinAguilar', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catlinAguilar', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catlinAguilar', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catlinAguilar', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'catlinAguilar', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sherrySilva', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sherrySilva', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sherrySilva', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sherrySilva', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sherrySilva', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'geraldRichards', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'geraldRichards', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'geraldRichards', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'geraldRichards', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'geraldRichards', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vanessaWillis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vanessaWillis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vanessaWillis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vanessaWillis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vanessaWillis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusMatthews', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusMatthews', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusMatthews', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusMatthews', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusMatthews', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraChapman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraChapman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraChapman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraChapman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mauraChapman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninamikeLawrence', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninamikeLawrence', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninamikeLawrence', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninamikeLawrence', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninamikeLawrence', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annGarza', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annGarza', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annGarza', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annGarza', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annGarza', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeVargas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeVargas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeVargas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeVargas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeVargas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisWatkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisWatkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisWatkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisWatkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisWatkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeWheeler', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeWheeler', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeWheeler', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeWheeler', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joeWheeler', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleLarson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleLarson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleLarson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleLarson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleLarson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bonnieCarlson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bonnieCarlson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bonnieCarlson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bonnieCarlson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bonnieCarlson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHarper', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHarper', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHarper', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHarper', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHarper', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colombineGeorge', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colombineGeorge', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colombineGeorge', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colombineGeorge', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colombineGeorge', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaGreene', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaGreene', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaGreene', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaGreene', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaGreene', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennBurke', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennBurke', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennBurke', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennBurke', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennBurke', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidGuzman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidGuzman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidGuzman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidGuzman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidGuzman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriMorrison', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriMorrison', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriMorrison', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriMorrison', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriMorrison', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisMunoz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisMunoz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisMunoz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisMunoz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisMunoz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertJacobs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertJacobs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertJacobs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertJacobs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertJacobs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaObrien', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaObrien', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaObrien', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaObrien', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaObrien', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennyLawson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennyLawson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennyLawson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennyLawson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jennyLawson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaFranklin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaFranklin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaFranklin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaFranklin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaFranklin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffLynch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffLynch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffLynch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffLynch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffLynch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaBishop', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaBishop', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaBishop', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaBishop', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jessicaBishop', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewCarr', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewCarr', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewCarr', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewCarr', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewCarr', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeSalazar', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeSalazar', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeSalazar', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeSalazar', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeSalazar', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeAustin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeAustin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeAustin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeAustin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreeAustin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMendez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMendez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMendez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMendez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMendez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyGilbert', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyGilbert', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyGilbert', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyGilbert', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyGilbert', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noalJensen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noalJensen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noalJensen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noalJensen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'noalJensen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWilliamson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWilliamson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWilliamson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWilliamson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWilliamson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMontgomery', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMontgomery', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMontgomery', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMontgomery', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMontgomery', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaHarvey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaHarvey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaHarvey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaHarvey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiaHarvey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edanaOliver', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edanaOliver', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edanaOliver', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edanaOliver', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edanaOliver', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'scottHowell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'scottHowell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'scottHowell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'scottHowell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'scottHowell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineDean', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineDean', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineDean', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineDean', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineDean', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillianHanson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillianHanson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillianHanson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillianHanson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jillianHanson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toyokoWeber', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toyokoWeber', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toyokoWeber', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toyokoWeber', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toyokoWeber', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieGarrett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieGarrett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieGarrett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieGarrett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieGarrett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasSims', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasSims', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasSims', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasSims', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasSims', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveBurton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveBurton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveBurton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveBurton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveBurton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonFuller', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonFuller', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonFuller', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonFuller', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonFuller', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaSoto', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaSoto', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaSoto', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaSoto', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaSoto', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorMccoy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorMccoy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorMccoy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorMccoy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'minorMccoy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWelch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWelch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWelch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWelch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelWelch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helenChen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helenChen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helenChen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helenChen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helenChen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katSchultz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katSchultz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katSchultz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katSchultz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katSchultz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaWalters', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaWalters', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaWalters', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaWalters', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaWalters', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieReid', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieReid', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieReid', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieReid', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieReid', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ameFields', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ameFields', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ameFields', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ameFields', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ameFields', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaWalsh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaWalsh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaWalsh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaWalsh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaWalsh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianLittle', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianLittle', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianLittle', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianLittle', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianLittle', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFowler', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFowler', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFowler', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFowler', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFowler', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mackenzieBowman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mackenzieBowman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mackenzieBowman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mackenzieBowman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mackenzieBowman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineDavidson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineDavidson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineDavidson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineDavidson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineDavidson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyMay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyMay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyMay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyMay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ashleyMay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattDay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattDay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattDay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattDay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattDay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaSchneider', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaSchneider', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaSchneider', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaSchneider', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaSchneider', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaemilyNewman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaemilyNewman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaemilyNewman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaemilyNewman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaemilyNewman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaBrewer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaBrewer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaBrewer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaBrewer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaBrewer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLucas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLucas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLucas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLucas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLucas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'asadHolland', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'asadHolland', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'asadHolland', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'asadHolland', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'asadHolland', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisWong', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisWong', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisWong', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisWong', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisWong', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tobiasBanks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tobiasBanks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tobiasBanks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tobiasBanks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tobiasBanks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianSantos', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianSantos', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianSantos', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianSantos', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianSantos', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'woodypaulineCurtis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'woodypaulineCurtis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'woodypaulineCurtis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'woodypaulineCurtis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'woodypaulineCurtis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaPearson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaPearson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaPearson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaPearson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'celiaPearson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisDelgado', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisDelgado', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisDelgado', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisDelgado', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexisDelgado', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyValdez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyValdez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyValdez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyValdez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyValdez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaPena', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaPena', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaPena', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaPena', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaPena', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinRios', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinRios', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinRios', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinRios', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinRios', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiapaulDouglas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiapaulDouglas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiapaulDouglas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiapaulDouglas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cynthiapaulDouglas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailSandoval', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailSandoval', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailSandoval', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailSandoval', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gailSandoval', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleBarrett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleBarrett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleBarrett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleBarrett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleBarrett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rociojasonHopkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rociojasonHopkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rociojasonHopkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rociojasonHopkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rociojasonHopkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahphilipKeller', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahphilipKeller', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahphilipKeller', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahphilipKeller', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahphilipKeller', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosGuerrero', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosGuerrero', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosGuerrero', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosGuerrero', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fivosGuerrero', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmanuelStanley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmanuelStanley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmanuelStanley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmanuelStanley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmanuelStanley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaBates', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaBates', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaBates', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaBates', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaBates', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaAlvarado', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaAlvarado', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaAlvarado', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaAlvarado', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaAlvarado', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaBeck', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaBeck', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaBeck', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaBeck', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaBeck', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineOrtega', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineOrtega', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineOrtega', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineOrtega', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christineOrtega', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretWade', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretWade', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretWade', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretWade', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretWade', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hyltonEstrada', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hyltonEstrada', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hyltonEstrada', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hyltonEstrada', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hyltonEstrada', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elenaContreras', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elenaContreras', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elenaContreras', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elenaContreras', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elenaContreras', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyBarnett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyBarnett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyBarnett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyBarnett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nancyBarnett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffCaldwell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffCaldwell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffCaldwell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffCaldwell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffCaldwell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hilarySantiago', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hilarySantiago', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hilarySantiago', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hilarySantiago', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hilarySantiago', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretLambert', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretLambert', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretLambert', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretLambert', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretLambert', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willPowers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willPowers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willPowers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willPowers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willPowers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielChambers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielChambers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielChambers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielChambers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielChambers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyNunez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyNunez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyNunez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyNunez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyNunez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mylaCraig', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mylaCraig', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mylaCraig', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mylaCraig', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mylaCraig', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendanLeonard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendanLeonard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendanLeonard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendanLeonard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendanLeonard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eliLowe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eliLowe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eliLowe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eliLowe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eliLowe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyRhodes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyRhodes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyRhodes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyRhodes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kellyRhodes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekByrd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekByrd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekByrd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekByrd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekByrd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamrachelGregory', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamrachelGregory', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamrachelGregory', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamrachelGregory', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamrachelGregory', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffShelton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffShelton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffShelton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffShelton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffShelton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaFrazier', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaFrazier', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaFrazier', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaFrazier', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaFrazier', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBecker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBecker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBecker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBecker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBecker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianMaldonado', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianMaldonado', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianMaldonado', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianMaldonado', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianMaldonado', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderFleming', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderFleming', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderFleming', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderFleming', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'helderFleming', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretVega', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretVega', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretVega', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretVega', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaretVega', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattevaSutton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattevaSutton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattevaSutton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattevaSutton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattevaSutton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikkiCohen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikkiCohen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikkiCohen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikkiCohen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikkiCohen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vinayakJennings', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vinayakJennings', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vinayakJennings', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vinayakJennings', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vinayakJennings', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'razanParks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'razanParks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'razanParks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'razanParks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'razanParks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaMcdaniel', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaMcdaniel', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaMcdaniel', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaMcdaniel', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaMcdaniel', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaWatts', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaWatts', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaWatts', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaWatts', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mariaWatts', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoBarker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoBarker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoBarker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoBarker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoBarker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinNorris', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinNorris', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinNorris', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinNorris', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kevinNorris', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zachVaughn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zachVaughn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zachVaughn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zachVaughn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zachVaughn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaVazquez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaVazquez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaVazquez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaVazquez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaVazquez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolHolt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolHolt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolHolt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolHolt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolHolt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arielSchwartz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arielSchwartz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arielSchwartz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arielSchwartz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arielSchwartz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredSteele', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredSteele', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredSteele', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredSteele', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaredSteele', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethBenson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethBenson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethBenson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethBenson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethBenson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelNeal', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelNeal', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelNeal', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelNeal', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelNeal', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelDominguez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelDominguez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelDominguez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelDominguez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelDominguez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHorton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHorton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHorton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHorton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidHorton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulTerry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulTerry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulTerry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulTerry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulTerry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaWolfe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaWolfe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaWolfe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaWolfe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaWolfe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaHale', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaHale', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaHale', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaHale', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'melissaHale', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaLyons', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaLyons', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaLyons', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaLyons', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaLyons', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiGraves', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiGraves', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiGraves', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiGraves', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiGraves', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHaynes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHaynes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHaynes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHaynes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanHaynes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMiles', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMiles', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMiles', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMiles', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonMiles', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinPark', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinPark', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinPark', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinPark', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinPark', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toniWarner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toniWarner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toniWarner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toniWarner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toniWarner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liesl &Padilla', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liesl &Padilla', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liesl &Padilla', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liesl &Padilla', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liesl &Padilla', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriBush', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriBush', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriBush', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriBush', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'loriBush', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanThornton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanThornton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanThornton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanThornton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanThornton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alMccarthy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alMccarthy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alMccarthy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alMccarthy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alMccarthy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattiMann', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattiMann', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattiMann', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattiMann', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pattiMann', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidZimmerman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidZimmerman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidZimmerman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidZimmerman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidZimmerman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyErickson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyErickson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyErickson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyErickson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sandyErickson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulFletcher', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulFletcher', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulFletcher', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulFletcher', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulFletcher', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isabelMckinney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isabelMckinney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isabelMckinney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isabelMckinney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isabelMckinney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasPage', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasPage', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasPage', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasPage', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasPage', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylesefiraDawson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylesefiraDawson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylesefiraDawson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylesefiraDawson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylesefiraDawson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshJoseph', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshJoseph', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshJoseph', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshJoseph', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshJoseph', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lucianaMarquez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lucianaMarquez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lucianaMarquez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lucianaMarquez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lucianaMarquez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaReeves', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaReeves', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaReeves', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaReeves', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joanaReeves', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'larryKlein', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'larryKlein', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'larryKlein', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'larryKlein', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'larryKlein', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dawsonEspinoza', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dawsonEspinoza', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dawsonEspinoza', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dawsonEspinoza', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dawsonEspinoza', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaBaldwin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaBaldwin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaBaldwin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaBaldwin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'orianaBaldwin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethMoran', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethMoran', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethMoran', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethMoran', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dorothysethMoran', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'oscarLove', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'oscarLove', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'oscarLove', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'oscarLove', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'oscarLove', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleRobbins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleRobbins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleRobbins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleRobbins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizdaleRobbins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHiggins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHiggins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHiggins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHiggins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHiggins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megBall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megBall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megBall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megBall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megBall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaCortez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaCortez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaCortez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaCortez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chriskristinaCortez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveLe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveLe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveLe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveLe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveLe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megGriffith', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megGriffith', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megGriffith', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megGriffith', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'megGriffith', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBowen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBowen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBowen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBowen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBowen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanSharp', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanSharp', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanSharp', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanSharp', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanSharp', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasCummings', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasCummings', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasCummings', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasCummings', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciakostasCummings', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianRamsey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianRamsey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianRamsey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianRamsey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derianRamsey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHardy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHardy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHardy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHardy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieHardy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraSwanson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraSwanson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraSwanson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraSwanson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraSwanson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaBarber', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaBarber', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaBarber', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaBarber', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaBarber', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahAcosta', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahAcosta', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahAcosta', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahAcosta', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hannahAcosta', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annaLuna', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annaLuna', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annaLuna', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annaLuna', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annaLuna', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaChandler', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaChandler', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaChandler', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaChandler', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robinvictoriaChandler', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyBlair', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyBlair', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyBlair', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyBlair', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyBlair', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDaniel', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDaniel', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDaniel', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDaniel', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julietDaniel', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyCross', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyCross', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyCross', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyCross', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyCross', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieSimon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieSimon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieSimon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieSimon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieSimon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franciscoDennis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franciscoDennis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franciscoDennis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franciscoDennis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franciscoDennis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinOconnor', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinOconnor', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinOconnor', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinOconnor', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinOconnor', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoQuinn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoQuinn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoQuinn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoQuinn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'riyoQuinn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateGross', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateGross', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateGross', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateGross', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateGross', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanNavarro', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanNavarro', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanNavarro', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanNavarro', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanNavarro', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMoss', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMoss', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMoss', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMoss', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josefaMoss', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamsaraFitzgerald', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamsaraFitzgerald', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamsaraFitzgerald', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamsaraFitzgerald', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'pamsaraFitzgerald', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffreyDoyle', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffreyDoyle', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffreyDoyle', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffreyDoyle', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffreyDoyle', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMclaughlin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMclaughlin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMclaughlin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMclaughlin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMclaughlin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleRojas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleRojas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleRojas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleRojas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielleRojas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'becRodgers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'becRodgers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'becRodgers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'becRodgers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'becRodgers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eranStevenson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eranStevenson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eranStevenson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eranStevenson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'eranStevenson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilSingh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilSingh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilSingh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilSingh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jilSingh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ericYang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ericYang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ericYang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ericYang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ericYang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marFigueroa', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marFigueroa', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marFigueroa', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marFigueroa', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marFigueroa', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenjiHarmon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenjiHarmon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenjiHarmon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenjiHarmon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenjiHarmon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessNewton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessNewton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessNewton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessNewton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessNewton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPaul', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPaul', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPaul', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPaul', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPaul', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayManning', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayManning', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayManning', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayManning', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayManning', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beantownGarner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beantownGarner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beantownGarner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beantownGarner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beantownGarner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fengMcgee', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fengMcgee', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fengMcgee', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fengMcgee', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fengMcgee', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielReese', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielReese', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielReese', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielReese', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielReese', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shahidFrancis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shahidFrancis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shahidFrancis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shahidFrancis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shahidFrancis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraBurgess', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraBurgess', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraBurgess', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraBurgess', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraBurgess', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caioAdkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caioAdkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caioAdkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caioAdkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caioAdkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timothyGoodman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timothyGoodman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timothyGoodman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timothyGoodman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timothyGoodman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'janaCurry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'janaCurry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'janaCurry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'janaCurry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'janaCurry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoBrady', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoBrady', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoBrady', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoBrady', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoBrady', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephChristensen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephChristensen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephChristensen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephChristensen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephChristensen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasPotter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasPotter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasPotter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasPotter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thomasPotter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaWalton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaWalton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaWalton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaWalton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaWalton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanGoodwin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanGoodwin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanGoodwin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanGoodwin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanGoodwin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nimerMullins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nimerMullins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nimerMullins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nimerMullins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nimerMullins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dayoMolina', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dayoMolina', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dayoMolina', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dayoMolina', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dayoMolina', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikhilWebster', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikhilWebster', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikhilWebster', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikhilWebster', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nikhilWebster', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaFischer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaFischer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaFischer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaFischer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'triciaFischer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangCampos', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangCampos', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangCampos', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangCampos', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangCampos', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessAvila', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessAvila', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessAvila', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessAvila', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessAvila', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'raheelSherman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'raheelSherman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'raheelSherman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'raheelSherman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'raheelSherman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessTodd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessTodd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessTodd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessTodd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessTodd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoChang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoChang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoChang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoChang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoChang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erickBlake', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erickBlake', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erickBlake', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erickBlake', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'erickBlake', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angieMalone', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angieMalone', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angieMalone', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angieMalone', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angieMalone', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangWolf', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangWolf', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangWolf', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangWolf', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangWolf', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dickHodges', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dickHodges', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dickHodges', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dickHodges', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dickHodges', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaJuarez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaJuarez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaJuarez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaJuarez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaJuarez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoGill', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoGill', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoGill', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoGill', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoGill', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveFarmer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveFarmer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveFarmer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveFarmer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'steveFarmer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeHines', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeHines', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeHines', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeHines', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeHines', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryGallagher', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryGallagher', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryGallagher', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryGallagher', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryGallagher', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenDuran', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenDuran', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenDuran', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenDuran', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenDuran', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaHubbard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaHubbard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaHubbard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaHubbard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaHubbard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCannon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCannon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCannon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCannon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCannon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMiranda', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMiranda', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMiranda', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMiranda', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyMiranda', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraWang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraWang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraWang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraWang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraWang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoSaunders', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoSaunders', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoSaunders', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoSaunders', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoSaunders', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaTate', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaTate', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaTate', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaTate', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alisaTate', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaMack', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaMack', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaMack', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaMack', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaMack', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexHammond', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexHammond', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexHammond', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexHammond', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexHammond', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCarrillo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCarrillo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCarrillo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCarrillo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCarrillo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTownsend', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTownsend', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTownsend', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTownsend', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTownsend', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaWise', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaWise', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaWise', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaWise', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaWise', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeIngram', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeIngram', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeIngram', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeIngram', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeIngram', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anneBarton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anneBarton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anneBarton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anneBarton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anneBarton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteMeija', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteMeija', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteMeija', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteMeija', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteMeija', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoAyala', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoAyala', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoAyala', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoAyala', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoAyala', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraSchroeder', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraSchroeder', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraSchroeder', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraSchroeder', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexandraSchroeder', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshiHampton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshiHampton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshiHampton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshiHampton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshiHampton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamilaRowe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamilaRowe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamilaRowe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamilaRowe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamilaRowe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteParsons', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteParsons', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteParsons', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteParsons', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'beatSuiteParsons', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aldrichFrank', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aldrichFrank', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aldrichFrank', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aldrichFrank', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aldrichFrank', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateWaters', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateWaters', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateWaters', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateWaters', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateWaters', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaStrickland', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaStrickland', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaStrickland', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaStrickland', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaStrickland', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carlOsborne', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carlOsborne', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carlOsborne', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carlOsborne', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carlOsborne', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexMaxwell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexMaxwell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexMaxwell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexMaxwell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexMaxwell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saleenaChan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saleenaChan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saleenaChan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saleenaChan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saleenaChan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusDeleon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusDeleon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusDeleon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusDeleon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marcusDeleon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mernaNorman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mernaNorman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mernaNorman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mernaNorman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mernaNorman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'puhanHarrington', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'puhanHarrington', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'puhanHarrington', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'puhanHarrington', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'puhanHarrington', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camillaCasey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camillaCasey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camillaCasey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camillaCasey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camillaCasey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaPatton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaPatton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaPatton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaPatton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaPatton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLogan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLogan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLogan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLogan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLogan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBowers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBowers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBowers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBowers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'isaacBowers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mitchelMueller', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mitchelMueller', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mitchelMueller', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mitchelMueller', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mitchelMueller', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stevenGlover', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stevenGlover', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stevenGlover', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stevenGlover', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stevenGlover', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFloyd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFloyd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFloyd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFloyd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFloyd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaHartman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaHartman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaHartman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaHartman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaHartman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenBuchanan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenBuchanan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenBuchanan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenBuchanan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenBuchanan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kavyaCobb', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kavyaCobb', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kavyaCobb', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kavyaCobb', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kavyaCobb', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFrench', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFrench', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFrench', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFrench', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFrench', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nathanKramer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nathanKramer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nathanKramer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nathanKramer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nathanKramer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'babakMccormick', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'babakMccormick', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'babakMccormick', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'babakMccormick', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'babakMccormick', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenClarke', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenClarke', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenClarke', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenClarke', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ellenClarke', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giselTyler', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giselTyler', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giselTyler', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giselTyler', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giselTyler', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaGibbs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaGibbs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaGibbs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaGibbs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaGibbs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMoody', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMoody', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMoody', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMoody', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMoody', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kuljeetConner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kuljeetConner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kuljeetConner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kuljeetConner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kuljeetConner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSparks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSparks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSparks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSparks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSparks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMcguire', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMcguire', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMcguire', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMcguire', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMcguire', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLeon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLeon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLeon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLeon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zoeLeon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaclynBauer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaclynBauer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaclynBauer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaclynBauer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaclynBauer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yosefNorton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yosefNorton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yosefNorton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yosefNorton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yosefNorton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chunKeiPope', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chunKeiPope', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chunKeiPope', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chunKeiPope', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chunKeiPope', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyFlynn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyFlynn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyFlynn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyFlynn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyFlynn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelHogan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelHogan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelHogan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelHogan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelHogan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaRobles', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaRobles', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaRobles', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaRobles', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaRobles', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettSalinas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettSalinas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettSalinas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettSalinas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettSalinas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYates', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYates', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYates', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYates', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYates', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaLindsey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaLindsey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaLindsey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaLindsey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaLindsey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielLloyd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielLloyd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielLloyd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielLloyd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielLloyd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoMarsh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoMarsh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoMarsh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoMarsh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'fernandoMarsh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'khaledMcbride', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'khaledMcbride', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'khaledMcbride', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'khaledMcbride', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'khaledMcbride', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOwen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOwen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOwen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOwen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOwen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangSolis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangSolis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangSolis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangSolis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hochiangSolis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenPham', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenPham', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenPham', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenPham', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marenPham', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'halLang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'halLang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'halLang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'halLang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'halLang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'teresaPratt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'teresaPratt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'teresaPratt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'teresaPratt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'teresaPratt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amadaLara', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amadaLara', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amadaLara', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amadaLara', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amadaLara', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettBrock', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettBrock', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettBrock', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettBrock', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettBrock', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shreyasBallard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shreyasBallard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shreyasBallard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shreyasBallard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shreyasBallard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maheshTrujillo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maheshTrujillo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maheshTrujillo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maheshTrujillo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maheshTrujillo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'prakharShaffer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'prakharShaffer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'prakharShaffer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'prakharShaffer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'prakharShaffer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annDrake', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annDrake', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annDrake', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annDrake', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annDrake', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielRoman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielRoman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielRoman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielRoman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielRoman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rohitAguirre', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rohitAguirre', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rohitAguirre', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rohitAguirre', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rohitAguirre', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettMorton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettMorton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettMorton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettMorton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brettMorton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaStokes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaStokes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaStokes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaStokes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'veronicaStokes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLamb', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLamb', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLamb', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLamb', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamLamb', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikePacheco', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikePacheco', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikePacheco', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikePacheco', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikePacheco', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPatrick', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPatrick', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPatrick', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPatrick', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessPatrick', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCochran', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCochran', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCochran', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCochran', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCochran', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaShepherd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaShepherd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaShepherd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaShepherd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaShepherd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evanCain', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evanCain', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evanCain', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evanCain', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'evanCain', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samBurnett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samBurnett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samBurnett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samBurnett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samBurnett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyHess', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyHess', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyHess', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyHess', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeremyHess', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elleLi', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elleLi', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elleLi', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elleLi', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elleLi', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCervantes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCervantes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCervantes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCervantes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'solntseCervantes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOlsen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOlsen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOlsen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOlsen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeOlsen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieBriggs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieBriggs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieBriggs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieBriggs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieBriggs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanOchoa', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanOchoa', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanOchoa', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanOchoa', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanOchoa', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mahipCabrera', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mahipCabrera', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mahipCabrera', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mahipCabrera', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mahipCabrera', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieVelasquez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieVelasquez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieVelasquez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieVelasquez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bernieVelasquez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shannonMontoya', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shannonMontoya', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shannonMontoya', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shannonMontoya', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shannonMontoya', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsRoth', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsRoth', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsRoth', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsRoth', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsRoth', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslMeyers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslMeyers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslMeyers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslMeyers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslMeyers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaCardenas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaCardenas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaCardenas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaCardenas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaCardenas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenFuentes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenFuentes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenFuentes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenFuentes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenFuentes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineWeiss', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineWeiss', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineWeiss', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineWeiss', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineWeiss', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnHoover', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnHoover', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnHoover', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnHoover', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shawnHoover', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsWilkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsWilkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsWilkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsWilkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsWilkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephNicholson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephNicholson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephNicholson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephNicholson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephNicholson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yasminaUnderwood', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yasminaUnderwood', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yasminaUnderwood', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yasminaUnderwood', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yasminaUnderwood', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineShort', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineShort', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineShort', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineShort', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineShort', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsCarson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsCarson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsCarson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsCarson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsCarson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyMorrow', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyMorrow', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyMorrow', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyMorrow', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyMorrow', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelbyLeeColon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelbyLeeColon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelbyLeeColon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelbyLeeColon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelbyLeeColon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulHolloway', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulHolloway', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulHolloway', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulHolloway', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulHolloway', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoSummers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoSummers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoSummers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoSummers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoSummers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyBryan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyBryan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyBryan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyBryan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mollyBryan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffPetersen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffPetersen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffPetersen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffPetersen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffPetersen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMckenzie', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMckenzie', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMckenzie', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMckenzie', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMckenzie', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antoinneSerrano', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antoinneSerrano', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antoinneSerrano', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antoinneSerrano', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antoinneSerrano', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslWilcox', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslWilcox', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslWilcox', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslWilcox', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslWilcox', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nickCarey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nickCarey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nickCarey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nickCarey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nickCarey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineClayton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineClayton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineClayton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineClayton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francineClayton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francinePoole', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francinePoole', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francinePoole', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francinePoole', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'francinePoole', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoCalderon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoCalderon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoCalderon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoCalderon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gustavoCalderon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGallegos', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGallegos', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGallegos', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGallegos', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGallegos', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGreer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGreer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGreer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGreer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judyGreer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainRivas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainRivas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainRivas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainRivas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainRivas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainGuerra', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainGuerra', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainGuerra', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainGuerra', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rainGuerra', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'abhishekDecker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'abhishekDecker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'abhishekDecker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'abhishekDecker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'abhishekDecker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCollier', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCollier', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCollier', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCollier', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCollier', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessWhitaker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessWhitaker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessWhitaker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessWhitaker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessWhitaker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBass', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBass', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBass', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBass', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBass', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueFlowers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueFlowers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueFlowers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueFlowers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueFlowers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDavenport', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDavenport', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDavenport', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDavenport', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDavenport', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueConley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueConley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueConley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueConley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueConley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHouston', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHouston', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHouston', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHouston', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHouston', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanHuff', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanHuff', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanHuff', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanHuff', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanHuff', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueCopeland', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueCopeland', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueCopeland', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueCopeland', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueCopeland', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeHood', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeHood', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeHood', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeHood', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeHood', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaMonroe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaMonroe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaMonroe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaMonroe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaMonroe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMassey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMassey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMassey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMassey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMassey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaRoberson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaRoberson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaRoberson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaRoberson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaRoberson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCombs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCombs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCombs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCombs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeCombs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hasanFranco', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hasanFranco', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hasanFranco', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hasanFranco', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hasanFranco', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valentinoLarsen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valentinoLarsen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valentinoLarsen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valentinoLarsen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valentinoLarsen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaPittman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaPittman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaPittman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaPittman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaPittman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacintoRandall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacintoRandall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacintoRandall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacintoRandall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jacintoRandall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaSkinner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaSkinner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaSkinner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaSkinner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kamaSkinner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWilkinson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWilkinson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWilkinson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWilkinson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaWilkinson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahKirby', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahKirby', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahKirby', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahKirby', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahKirby', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaCameron', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaCameron', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaCameron', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaCameron', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaCameron', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBridges', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBridges', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBridges', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBridges', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBridges', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAnthony', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAnthony', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAnthony', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAnthony', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAnthony', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaRichard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaRichard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaRichard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaRichard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dianaRichard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeKirk', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeKirk', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeKirk', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeKirk', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeKirk', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leeBruce', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leeBruce', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leeBruce', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leeBruce', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leeBruce', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanSingleton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanSingleton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanSingleton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanSingleton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alanSingleton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMathis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMathis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMathis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMathis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stanleysueMathis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBradford', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBradford', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBradford', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBradford', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBradford', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoone', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoone', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoone', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoone', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoone', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAbbott', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAbbott', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAbbott', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAbbott', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAbbott', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dimitraCharles', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dimitraCharles', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dimitraCharles', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dimitraCharles', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dimitraCharles', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAllison', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAllison', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAllison', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAllison', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAllison', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSweeney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSweeney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSweeney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSweeney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaSweeney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAtkinson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAtkinson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAtkinson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAtkinson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaAtkinson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenHorn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenHorn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenHorn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenHorn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenHorn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahJefferson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahJefferson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahJefferson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahJefferson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahJefferson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRosales', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRosales', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRosales', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRosales', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRosales', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYork', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYork', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYork', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYork', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaYork', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChristian', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChristian', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChristian', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChristian', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChristian', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarraPhelps', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarraPhelps', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarraPhelps', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarraPhelps', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarraPhelps', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katerinaFarrell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katerinaFarrell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katerinaFarrell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katerinaFarrell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katerinaFarrell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCastaneda', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCastaneda', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCastaneda', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCastaneda', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaCastaneda', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinNash', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinNash', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinNash', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinNash', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinNash', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaDickerson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaDickerson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaDickerson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaDickerson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaDickerson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBond', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBond', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBond', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBond', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBond', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielWyatt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielWyatt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielWyatt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielWyatt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielWyatt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFoley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFoley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFoley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFoley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaFoley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChase', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChase', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChase', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChase', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaChase', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaGates', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaGates', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaGates', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaGates', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaGates', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristaVincent', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristaVincent', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristaVincent', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristaVincent', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristaVincent', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMathews', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMathews', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMathews', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMathews', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaMathews', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHodge', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHodge', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHodge', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHodge', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHodge', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeGarrison', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeGarrison', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeGarrison', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeGarrison', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeGarrison', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTrevino', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTrevino', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTrevino', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTrevino', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaTrevino', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaVillarreal', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaVillarreal', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaVillarreal', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaVillarreal', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaVillarreal', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHeath', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHeath', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHeath', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHeath', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kenHeath', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanyaDalton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanyaDalton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanyaDalton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanyaDalton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanyaDalton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexValencia', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexValencia', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexValencia', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexValencia', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexValencia', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayCallahan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayCallahan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayCallahan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayCallahan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayCallahan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHensley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHensley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHensley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHensley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHensley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidAtkins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidAtkins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidAtkins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidAtkins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidAtkins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayHuffman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayHuffman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayHuffman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayHuffman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stayHuffman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRoy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRoy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRoy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRoy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeRoy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoyer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoyer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoyer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoyer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaBoyer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinShields', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinShields', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinShields', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinShields', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinShields', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHancock', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHancock', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHancock', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHancock', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'karaHancock', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessGrimes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessGrimes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessGrimes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessGrimes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessGrimes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisGlenn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisGlenn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisGlenn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisGlenn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'louisGlenn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorCline', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorCline', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorCline', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorCline', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorCline', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepDelacruz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepDelacruz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepDelacruz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepDelacruz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepDelacruz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylCamacho', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylCamacho', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylCamacho', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylCamacho', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylCamacho', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heatherDillon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heatherDillon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heatherDillon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heatherDillon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heatherDillon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willParrish', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willParrish', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willParrish', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willParrish', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willParrish', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaOneill', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaOneill', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaOneill', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaOneill', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindaOneill', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'preetiMelton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'preetiMelton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'preetiMelton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'preetiMelton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'preetiMelton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'justinBooth', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'justinBooth', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'justinBooth', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'justinBooth', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'justinBooth', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardKane', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardKane', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardKane', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardKane', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardKane', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'enzoBerg', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'enzoBerg', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'enzoBerg', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'enzoBerg', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'enzoBerg', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonHarrell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonHarrell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonHarrell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonHarrell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonHarrell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'konstantinosPitts', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'konstantinosPitts', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'konstantinosPitts', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'konstantinosPitts', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'konstantinosPitts', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sabrinaSavage', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sabrinaSavage', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sabrinaSavage', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sabrinaSavage', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sabrinaSavage', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franklinWiggins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franklinWiggins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franklinWiggins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franklinWiggins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'franklinWiggins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'allyBrennan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'allyBrennan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'allyBrennan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'allyBrennan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'allyBrennan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseSalas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseSalas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseSalas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseSalas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseSalas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephsueMarks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephsueMarks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephsueMarks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephsueMarks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephsueMarks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ginaRusso', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ginaRusso', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ginaRusso', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ginaRusso', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ginaRusso', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sueSawyer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sueSawyer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sueSawyer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sueSawyer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sueSawyer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyBaxter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyBaxter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyBaxter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyBaxter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'zacharyBaxter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'benjaminGolden', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'benjaminGolden', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'benjaminGolden', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'benjaminGolden', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'benjaminGolden', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleHutchinson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleHutchinson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleHutchinson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleHutchinson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleHutchinson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaLiu', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaLiu', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaLiu', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaLiu', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rebeccaLiu', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindsayWalter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindsayWalter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindsayWalter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindsayWalter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindsayWalter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeMcdowell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeMcdowell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeMcdowell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeMcdowell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeMcdowell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardWiley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardWiley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardWiley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardWiley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardWiley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maloryRich', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maloryRich', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maloryRich', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maloryRich', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maloryRich', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesHumphrey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesHumphrey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesHumphrey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesHumphrey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesHumphrey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerJohns', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerJohns', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerJohns', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerJohns', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerJohns', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaKoch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaKoch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaKoch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaKoch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreaKoch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesSuarez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesSuarez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesSuarez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesSuarez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesSuarez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethHobbs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethHobbs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethHobbs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethHobbs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethHobbs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepBeard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepBeard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepBeard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepBeard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepBeard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterGilmore', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterGilmore', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterGilmore', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterGilmore', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peterGilmore', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulinaIbarra', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulinaIbarra', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulinaIbarra', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulinaIbarra', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulinaIbarra', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffKeith', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffKeith', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffKeith', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffKeith', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jeffKeith', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanMacias', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanMacias', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanMacias', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanMacias', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanMacias', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorKhan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorKhan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorKhan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorKhan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorKhan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'haleyAndrade', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'haleyAndrade', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'haleyAndrade', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'haleyAndrade', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'haleyAndrade', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethWare', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethWare', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethWare', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethWare', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bethWare', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseStephenson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseStephenson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseStephenson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseStephenson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseStephenson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billHenson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billHenson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billHenson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billHenson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billHenson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'keshavWilkerson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'keshavWilkerson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'keshavWilkerson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'keshavWilkerson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'keshavWilkerson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewDyer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewDyer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewDyer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewDyer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewDyer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsMcclure', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsMcclure', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsMcclure', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsMcclure', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsMcclure', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesBlackwell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesBlackwell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesBlackwell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesBlackwell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jamesBlackwell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMercado', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMercado', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMercado', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMercado', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMercado', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyTanner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyTanner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyTanner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyTanner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyTanner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsEaton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsEaton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsEaton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsEaton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsEaton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsClay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsClay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsClay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsClay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsClay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timBarron', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timBarron', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timBarron', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timBarron', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'timBarron', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsBeasley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsBeasley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsBeasley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsBeasley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bostonrentalsBeasley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseOneal', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseOneal', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseOneal', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseOneal', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseOneal', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josePreston', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josePreston', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josePreston', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josePreston', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josePreston', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepSmall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepSmall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepSmall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepSmall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepSmall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendonWu', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendonWu', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendonWu', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendonWu', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brendonWu', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieZamora', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieZamora', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieZamora', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieZamora', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieZamora', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kimMacdonald', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kimMacdonald', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kimMacdonald', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kimMacdonald', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kimMacdonald', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyVance', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyVance', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyVance', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyVance', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'anthonyVance', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colleenSnow', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colleenSnow', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colleenSnow', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colleenSnow', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'colleenSnow', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMcclain', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMcclain', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMcclain', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMcclain', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marianaMcclain', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorStafford', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorStafford', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorStafford', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorStafford', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorStafford', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maiteOrozco', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maiteOrozco', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maiteOrozco', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maiteOrozco', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maiteOrozco', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judithBarry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judithBarry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judithBarry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judithBarry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'judithBarry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethEnglish', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethEnglish', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethEnglish', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethEnglish', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethEnglish', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyShannon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyShannon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyShannon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyShannon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emilyShannon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'frankKline', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'frankKline', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'frankKline', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'frankKline', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'frankKline', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gretchenJacobson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gretchenJacobson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gretchenJacobson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gretchenJacobson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gretchenJacobson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeWoodard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeWoodard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeWoodard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeWoodard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeWoodard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHuang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHuang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHuang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHuang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andrewHuang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseKemp', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseKemp', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseKemp', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseKemp', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseKemp', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMosley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMosley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMosley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMosley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielMosley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelPrince', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelPrince', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelPrince', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelPrince', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rachelPrince', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorMerritt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorMerritt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorMerritt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorMerritt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorMerritt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHurst', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHurst', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHurst', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHurst', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHurst', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeVillanueva', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeVillanueva', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeVillanueva', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeVillanueva', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paigeVillanueva', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamRoach', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamRoach', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamRoach', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamRoach', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adamRoach', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseNolan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseNolan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseNolan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseNolan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joseNolan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trishLam', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trishLam', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trishLam', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trishLam', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trishLam', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanchitYoder', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanchitYoder', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanchitYoder', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanchitYoder', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sanchitYoder', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giovanniMccullough', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giovanniMccullough', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giovanniMccullough', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giovanniMccullough', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'giovanniMccullough', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaLester', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaLester', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaLester', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaLester', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tanyaLester', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'howardSantana', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'howardSantana', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'howardSantana', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'howardSantana', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'howardSantana', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paoloValenzuela', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paoloValenzuela', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paoloValenzuela', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paoloValenzuela', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paoloValenzuela', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nataliaWinters', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nataliaWinters', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nataliaWinters', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nataliaWinters', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nataliaWinters', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenBarrera', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenBarrera', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenBarrera', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenBarrera', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenBarrera', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mairaLeach', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mairaLeach', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mairaLeach', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mairaLeach', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mairaLeach', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dashaOrr', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dashaOrr', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dashaOrr', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dashaOrr', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'dashaOrr', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nirmalBerger', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nirmalBerger', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nirmalBerger', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nirmalBerger', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'nirmalBerger', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMckee', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMckee', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMckee', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMckee', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMckee', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayStrong', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayStrong', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayStrong', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayStrong', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayStrong', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveConway', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveConway', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveConway', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveConway', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'daveConway', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stephenStein', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stephenStein', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stephenStein', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stephenStein', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'stephenStein', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joyWhitehead', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joyWhitehead', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joyWhitehead', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joyWhitehead', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joyWhitehead', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camilleBullock', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camilleBullock', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camilleBullock', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camilleBullock', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'camilleBullock', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradEscobar', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradEscobar', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradEscobar', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradEscobar', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradEscobar', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'panagiotisuzyKnox', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'panagiotisuzyKnox', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'panagiotisuzyKnox', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'panagiotisuzyKnox', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'panagiotisuzyKnox', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMeadows', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMeadows', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMeadows', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMeadows', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sleepMeadows', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieSolomon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieSolomon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieSolomon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieSolomon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieSolomon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonVelez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonVelez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonVelez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonVelez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonVelez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leslieOdonnell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leslieOdonnell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leslieOdonnell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leslieOdonnell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'leslieOdonnell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateKerr', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateKerr', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateKerr', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateKerr', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateKerr', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katharineStout', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katharineStout', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katharineStout', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katharineStout', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katharineStout', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jannaBlankenship', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jannaBlankenship', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jannaBlankenship', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jannaBlankenship', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jannaBlankenship', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'furnishedBrowing', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'furnishedBrowing', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'furnishedBrowing', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'furnishedBrowing', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'furnishedBrowing', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKent', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKent', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKent', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKent', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKent', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cindymarkLozano', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cindymarkLozano', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cindymarkLozano', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cindymarkLozano', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'cindymarkLozano', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adelineBartlett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adelineBartlett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adelineBartlett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adelineBartlett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adelineBartlett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorPruitt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorPruitt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorPruitt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorPruitt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorPruitt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brieBuck', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brieBuck', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brieBuck', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brieBuck', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brieBuck', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradBarr', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradBarr', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradBarr', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradBarr', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradBarr', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexmorganeGaines', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexmorganeGaines', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexmorganeGaines', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexmorganeGaines', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexmorganeGaines', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorDurham', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorDurham', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorDurham', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorDurham', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorDurham', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerGentry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerGentry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerGentry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerGentry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylerGentry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'soniaMcintyre', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'soniaMcintyre', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'soniaMcintyre', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'soniaMcintyre', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'soniaMcintyre', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ariellelucasSloan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ariellelucasSloan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ariellelucasSloan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ariellelucasSloan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ariellelucasSloan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiMelendez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiMelendez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiMelendez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiMelendez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreiMelendez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleRocha', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleRocha', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleRocha', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleRocha', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danieleRocha', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHerman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHerman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHerman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHerman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHerman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaySexton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaySexton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaySexton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaySexton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaySexton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayMoon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayMoon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayMoon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayMoon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayMoon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jorgeHendricks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jorgeHendricks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jorgeHendricks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jorgeHendricks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jorgeHendricks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorRangel', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorRangel', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorRangel', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorRangel', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorRangel', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieStark', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieStark', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieStark', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieStark', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'julieStark', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coleLowery', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coleLowery', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coleLowery', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coleLowery', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'coleLowery', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexaHardin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexaHardin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexaHardin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexaHardin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexaHardin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHull', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHull', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHull', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHull', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorHull', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylSellers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylSellers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylSellers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylSellers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carloscherylSellers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorEllison', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorEllison', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorEllison', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorEllison', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'drorEllison', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethCalhoun', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethCalhoun', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethCalhoun', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethCalhoun', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elizabethCalhoun', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomGillespie', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomGillespie', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomGillespie', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomGillespie', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tomGillespie', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenMora', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenMora', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenMora', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenMora', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurenMora', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanKnapp', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanKnapp', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanKnapp', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanKnapp', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'susanKnapp', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidMccall', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidMccall', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidMccall', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidMccall', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidMccall', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinMorse', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinMorse', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinMorse', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinMorse', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'caitlinMorse', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toddDorsey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toddDorsey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toddDorsey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toddDorsey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'toddDorsey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonWeeks', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonWeeks', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonWeeks', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonWeeks', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonWeeks', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineNielsen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineNielsen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineNielsen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineNielsen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineNielsen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'matthewLivingston', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'matthewLivingston', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'matthewLivingston', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'matthewLivingston', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'matthewLivingston', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jerrykamilLeblanc', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jerrykamilLeblanc', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jerrykamilLeblanc', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jerrykamilLeblanc', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jerrykamilLeblanc', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hansMclean', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hansMclean', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hansMclean', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hansMclean', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'hansMclean', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinBradshaw', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinBradshaw', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinBradshaw', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinBradshaw', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kristinBradshaw', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianGlass', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianGlass', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianGlass', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianGlass', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianGlass', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephMiddleton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephMiddleton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephMiddleton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephMiddleton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'josephMiddleton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBuckley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBuckley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBuckley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBuckley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonBuckley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arnaldoSchaefer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arnaldoSchaefer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arnaldoSchaefer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arnaldoSchaefer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arnaldoSchaefer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookFrost', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookFrost', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookFrost', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookFrost', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookFrost', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHowe', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHowe', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHowe', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHowe', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHowe', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekHouse', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekHouse', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekHouse', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekHouse', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'derekHouse', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinMcintosh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinMcintosh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinMcintosh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinMcintosh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinMcintosh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaHo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaHo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaHo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaHo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaHo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaPennington', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaPennington', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaPennington', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaPennington', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taylaPennington', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelReilly', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelReilly', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelReilly', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelReilly', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelReilly', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHebert', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHebert', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHebert', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHebert', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHebert', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deanMcfarland', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deanMcfarland', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deanMcfarland', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deanMcfarland', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'deanMcfarland', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahHickman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahHickman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahHickman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahHickman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahHickman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willNoble', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willNoble', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willNoble', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willNoble', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willNoble', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulSpears', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulSpears', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulSpears', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulSpears', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'paulSpears', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kartikConrad', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kartikConrad', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kartikConrad', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kartikConrad', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kartikConrad', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willArias', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willArias', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willArias', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willArias', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willArias', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willGalvan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willGalvan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willGalvan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willGalvan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willGalvan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidVelazquez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidVelazquez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidVelazquez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidVelazquez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidVelazquez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHuynh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHuynh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHuynh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHuynh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHuynh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelFrederick', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelFrederick', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelFrederick', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelFrederick', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelFrederick', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRandolph', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRandolph', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRandolph', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRandolph', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRandolph', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willCantu', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willCantu', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willCantu', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willCantu', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willCantu', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineFitzpatrick', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineFitzpatrick', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineFitzpatrick', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineFitzpatrick', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'carolineFitzpatrick', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaMahoney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaMahoney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaMahoney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaMahoney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaMahoney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexPeck', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexPeck', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexPeck', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexPeck', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexPeck', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleVilla', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleVilla', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleVilla', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleVilla', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleVilla', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taniaMichael', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taniaMichael', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taniaMichael', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taniaMichael', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'taniaMichael', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaDonovan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaDonovan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaDonovan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaDonovan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaDonovan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'feliciaMcconnell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'feliciaMcconnell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'feliciaMcconnell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'feliciaMcconnell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'feliciaMcconnell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willWalls', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willWalls', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willWalls', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willWalls', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willWalls', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexBoyle', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexBoyle', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexBoyle', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexBoyle', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alexBoyle', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'garyMayer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'garyMayer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'garyMayer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'garyMayer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'garyMayer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'betsyZuniga', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'betsyZuniga', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'betsyZuniga', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'betsyZuniga', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'betsyZuniga', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaGiles', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaGiles', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaGiles', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaGiles', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaGiles', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spPineda', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spPineda', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spPineda', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spPineda', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spPineda', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maxPace', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maxPace', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maxPace', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maxPace', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maxPace', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanHurley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanHurley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanHurley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanHurley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanHurley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jumbeMays', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jumbeMays', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jumbeMays', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jumbeMays', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jumbeMays', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaMcmillan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaMcmillan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaMcmillan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaMcmillan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaMcmillan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayleeseCrosby', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayleeseCrosby', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayleeseCrosby', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayleeseCrosby', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayleeseCrosby', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marAyers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marAyers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marAyers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marAyers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marAyers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spCase', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spCase', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spCase', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spCase', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spCase', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBentley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBentley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBentley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBentley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jenniferBentley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christianShepard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christianShepard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christianShepard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christianShepard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christianShepard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithEverett', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithEverett', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithEverett', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithEverett', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithEverett', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michellePugh', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michellePugh', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michellePugh', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michellePugh', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michellePugh', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleDavid', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleDavid', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleDavid', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleDavid', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleDavid', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elifMcmahon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elifMcmahon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elifMcmahon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elifMcmahon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'elifMcmahon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billDunlap', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billDunlap', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billDunlap', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billDunlap', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'billDunlap', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBender', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBender', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBender', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBender', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBender', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHahn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHahn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHahn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHahn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spHahn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'octavioHarding', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'octavioHarding', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'octavioHarding', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'octavioHarding', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'octavioHarding', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaAcevedo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaAcevedo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaAcevedo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaAcevedo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'monicaAcevedo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valerieRaymond', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valerieRaymond', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valerieRaymond', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valerieRaymond', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'valerieRaymond', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBlackburn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBlackburn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBlackburn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBlackburn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kaitlinBlackburn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryDuffy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryDuffy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryDuffy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryDuffy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryDuffy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyLandry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyLandry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyLandry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyLandry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyLandry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDougherty', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDougherty', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDougherty', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDougherty', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDougherty', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chuyangBautista', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chuyangBautista', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chuyangBautista', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chuyangBautista', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chuyangBautista', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yvonneShah', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yvonneShah', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yvonneShah', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yvonneShah', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yvonneShah', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaPotts', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaPotts', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaPotts', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaPotts', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaPotts', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ilanArroyo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ilanArroyo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ilanArroyo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ilanArroyo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ilanArroyo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willValentine', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willValentine', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willValentine', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willValentine', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willValentine', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMeza', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMeza', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMeza', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMeza', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMeza', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoGould', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoGould', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoGould', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoGould', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ricardoGould', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianagianniVaughan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianagianniVaughan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianagianniVaughan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianagianniVaughan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'adrianagianniVaughan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marciaFry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marciaFry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marciaFry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marciaFry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marciaFry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRush', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRush', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRush', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRush', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahRush', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizlucianAvery', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizlucianAvery', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizlucianAvery', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizlucianAvery', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lizlucianAvery', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heidiHerring', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heidiHerring', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heidiHerring', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heidiHerring', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'heidiHerring', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDodson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDodson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDodson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDodson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinDodson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaClements', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaClements', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaClements', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaClements', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaClements', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithSampson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithSampson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithSampson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithSampson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'edithSampson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'banditaTapia', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'banditaTapia', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'banditaTapia', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'banditaTapia', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'banditaTapia', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'randyBean', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'randyBean', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'randyBean', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'randyBean', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'randyBean', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahLynn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahLynn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahLynn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahLynn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahLynn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyeCrane', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyeCrane', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyeCrane', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyeCrane', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyeCrane', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathecandiceFarley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathecandiceFarley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathecandiceFarley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathecandiceFarley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathecandiceFarley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyreeCisneros', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyreeCisneros', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyreeCisneros', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyreeCisneros', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'tyreeCisneros', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieBenton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieBenton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieBenton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieBenton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieBenton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelleyAshley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelleyAshley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelleyAshley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelleyAshley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shelleyAshley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreinaMckay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreinaMckay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreinaMckay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreinaMckay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'andreinaMckay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFinley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFinley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFinley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFinley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'annFinley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasiyaBest', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasiyaBest', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasiyaBest', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasiyaBest', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasiyaBest', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryBlevins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryBlevins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryBlevins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryBlevins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryBlevins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ziyadFriedman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ziyadFriedman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ziyadFriedman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ziyadFriedman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ziyadFriedman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelMoses', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelMoses', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelMoses', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelMoses', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michaelMoses', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroSosa', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroSosa', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroSosa', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroSosa', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroSosa', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBlanchard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBlanchard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBlanchard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBlanchard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBlanchard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyHuber', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyHuber', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyHuber', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyHuber', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyHuber', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFrye', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFrye', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFrye', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFrye', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanFrye', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaKrueger', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaKrueger', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaKrueger', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaKrueger', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaKrueger', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelBernard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelBernard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelBernard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelBernard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'angelBernard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yilkalRosario', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yilkalRosario', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yilkalRosario', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yilkalRosario', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yilkalRosario', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRubio', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRubio', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRubio', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRubio', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryRubio', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradMullen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradMullen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradMullen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradMullen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bradMullen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBenjamin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBenjamin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBenjamin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBenjamin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBenjamin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHaley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHaley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHaley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHaley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryHaley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinChung', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinChung', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinChung', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinChung', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinChung', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMoyer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMoyer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMoyer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMoyer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMoyer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateChoi', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateChoi', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateChoi', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateChoi', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kateChoi', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaHorne', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaHorne', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaHorne', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaHorne', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'margaritaHorne', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookYu', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookYu', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookYu', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookYu', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookYu', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroWoodward', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroWoodward', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroWoodward', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroWoodward', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'alejandroWoodward', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spAli', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spAli', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spAli', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spAli', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spAli', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spNixon', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spNixon', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spNixon', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spNixon', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'spNixon', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trevorHayden', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trevorHayden', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trevorHayden', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trevorHayden', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'trevorHayden', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRivers', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRivers', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRivers', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRivers', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanRivers', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaysonEstes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaysonEstes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaysonEstes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaysonEstes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jaysonEstes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMccarty', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMccarty', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMccarty', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMccarty', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMccarty', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleRichmond', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleRichmond', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleRichmond', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleRichmond', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleRichmond', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianStuart', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianStuart', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianStuart', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianStuart', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'firlianStuart', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMaynard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMaynard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMaynard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMaynard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanMaynard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaBrandt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaBrandt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaBrandt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaBrandt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaBrandt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ronnieOconnell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ronnieOconnell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ronnieOconnell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ronnieOconnell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ronnieOconnell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaHanna', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaHanna', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaHanna', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaHanna', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'juliaHanna', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yishaSanford', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yishaSanford', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yishaSanford', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yishaSanford', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yishaSanford', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willSheppard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willSheppard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willSheppard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willSheppard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willSheppard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaChurch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaChurch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaChurch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaChurch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aihuaChurch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaBurch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaBurch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaBurch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaBurch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'emmaBurch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikLevy', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikLevy', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikLevy', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikLevy', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikLevy', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyRasmussen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyRasmussen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyRasmussen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyRasmussen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyRasmussen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleCoffey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleCoffey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleCoffey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleCoffey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleCoffey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanPonce', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanPonce', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanPonce', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanPonce', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanPonce', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katherineFaulkner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katherineFaulkner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katherineFaulkner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katherineFaulkner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'katherineFaulkner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDonaldson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDonaldson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDonaldson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDonaldson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDonaldson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahSchmitt', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahSchmitt', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahSchmitt', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahSchmitt', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahSchmitt', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanNovak', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanNovak', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanNovak', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanNovak', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanNovak', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kandiCosta', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kandiCosta', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kandiCosta', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kandiCosta', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kandiCosta', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ervinMontes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ervinMontes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ervinMontes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ervinMontes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ervinMontes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinBooker', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinBooker', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinBooker', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinBooker', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mekkinBooker', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyCordova', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyCordova', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyCordova', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyCordova', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'huggyCordova', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahWaller', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahWaller', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahWaller', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahWaller', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahWaller', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahArellano', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahArellano', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahArellano', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahArellano', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'sarahArellano', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMaddox', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMaddox', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMaddox', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMaddox', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMaddox', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marlacoeMata', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marlacoeMata', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marlacoeMata', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marlacoeMata', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marlacoeMata', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyBonilla', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyBonilla', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyBonilla', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyBonilla', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lindseyBonilla', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryStanton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryStanton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryStanton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryStanton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'terryStanton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'claudiaCompton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'claudiaCompton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'claudiaCompton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'claudiaCompton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'claudiaCompton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKaufman', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKaufman', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKaufman', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKaufman', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jasonKaufman', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDudley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDudley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDudley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDudley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jonathanDudley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadMcpherson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadMcpherson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadMcpherson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadMcpherson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chadMcpherson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chloeBeltran', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chloeBeltran', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chloeBeltran', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chloeBeltran', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chloeBeltran', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'CarlosDickson', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'CarlosDickson', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'CarlosDickson', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'CarlosDickson', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'CarlosDickson', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMccann', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMccann', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMccann', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMccann', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'georgeMccann', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arifVillegas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arifVillegas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arifVillegas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arifVillegas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'arifVillegas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willProctor', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willProctor', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willProctor', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willProctor', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willProctor', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jHester', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jHester', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jHester', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jHester', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jHester', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maryCantrell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maryCantrell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maryCantrell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maryCantrell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'maryCantrell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessDaugherty', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessDaugherty', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessDaugherty', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessDaugherty', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessDaugherty', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCherry', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCherry', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCherry', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCherry', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessCherry', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBray', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBray', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBray', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBray', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessBray', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaDavila', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaDavila', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaDavila', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaDavila', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaDavila', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessRowland', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessRowland', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessRowland', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessRowland', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seamlessRowland', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurelLevine', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurelLevine', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurelLevine', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurelLevine', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'laurelLevine', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaMadden', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaMadden', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaMadden', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaMadden', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'amandaMadden', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslSpence', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslSpence', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslSpence', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslSpence', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lieslSpence', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ceGood', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ceGood', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ceGood', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ceGood', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ceGood', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willIrwin', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willIrwin', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willIrwin', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willIrwin', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willIrwin', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattWerner', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattWerner', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattWerner', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattWerner', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mattWerner', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yoshikaKrause', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yoshikaKrause', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yoshikaKrause', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yoshikaKrause', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yoshikaKrause', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertPetty', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertPetty', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertPetty', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertPetty', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertPetty', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWhitney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWhitney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWhitney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWhitney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'davidWhitney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'javierBaird', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'javierBaird', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'javierBaird', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'javierBaird', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'javierBaird', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHooper', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHooper', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHooper', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHooper', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jayHooper', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylePollard', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylePollard', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylePollard', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylePollard', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kylePollard', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshZavala', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshZavala', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshZavala', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshZavala', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshZavala', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookJarvis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookJarvis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookJarvis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookJarvis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookJarvis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHolden', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHolden', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHolden', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHolden', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHolden', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHaas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHaas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHaas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHaas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookHaas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisHendrix', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisHendrix', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisHendrix', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisHendrix', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'chrisHendrix', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMcgrath', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMcgrath', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMcgrath', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMcgrath', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookMcgrath', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBird', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBird', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBird', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBird', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookBird', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaLucero', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaLucero', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaLucero', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaLucero', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'christinaLucero', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshTerrell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshTerrell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshTerrell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshTerrell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshTerrell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kyleRiggs', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kyleRiggs', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kyleRiggs', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kyleRiggs', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kyleRiggs', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaJoyce', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaJoyce', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaJoyce', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaJoyce', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaJoyce', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'masonMercer', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'masonMercer', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'masonMercer', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'masonMercer', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'masonMercer', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRollins', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRollins', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRollins', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRollins', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRollins', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshGalloway', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshGalloway', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshGalloway', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshGalloway', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'joshGalloway', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDuke', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDuke', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDuke', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDuke', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDuke', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookOdom', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookOdom', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookOdom', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookOdom', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookOdom', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gregoryAndersen', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gregoryAndersen', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gregoryAndersen', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gregoryAndersen', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gregoryAndersen', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDowns', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDowns', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDowns', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDowns', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookDowns', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathelisaHatfield', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathelisaHatfield', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathelisaHatfield', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathelisaHatfield', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kathelisaHatfield', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'innBenitez', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'innBenitez', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'innBenitez', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'innBenitez', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'innBenitez', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaArcher', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaArcher', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaArcher', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaArcher', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'ninaArcher', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHuerta', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHuerta', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHuerta', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHuerta', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHuerta', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaTravis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaTravis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaTravis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaTravis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaTravis', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMcneil', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMcneil', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMcneil', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMcneil', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'willMcneil', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHinton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHinton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHinton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHinton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'marieHinton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossZhang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossZhang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossZhang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossZhang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'rossZhang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaHays', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaHays', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaHays', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaHays', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'viktoriaHays', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelMayo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelMayo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelMayo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelMayo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'samuelMayo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bridgetFritz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bridgetFritz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bridgetFritz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bridgetFritz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'bridgetFritz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yucelBranch', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yucelBranch', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yucelBranch', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yucelBranch', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'yucelBranch', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaMooney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaMooney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaMooney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaMooney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaMooney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaEwing', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaEwing', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaEwing', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaEwing', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaEwing', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRitter', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRitter', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRitter', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRitter', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'flatbookRitter', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardEsparza', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardEsparza', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardEsparza', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardEsparza', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'richardEsparza', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antonioFrey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antonioFrey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antonioFrey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antonioFrey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'antonioFrey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'glennBraun', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'glennBraun', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'glennBraun', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'glennBraun', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'glennBraun', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jancyGay', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jancyGay', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jancyGay', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jancyGay', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'jancyGay', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gabriellaRiddle', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gabriellaRiddle', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gabriellaRiddle', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gabriellaRiddle', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'gabriellaRiddle', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'johnHaney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'johnHaney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'johnHaney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'johnHaney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'johnHaney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kitKaiser', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kitKaiser', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kitKaiser', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kitKaiser', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'kitKaiser', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaHolder', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaHolder', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaHolder', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaHolder', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaHolder', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'berkeleyChaney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'berkeleyChaney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'berkeleyChaney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'berkeleyChaney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'berkeleyChaney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleMcknight', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleMcknight', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleMcknight', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleMcknight', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'michelleMcknight', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianGamble', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianGamble', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianGamble', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianGamble', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brianGamble', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohammadVang', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohammadVang', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohammadVang', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohammadVang', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mohammadVang', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaCooley', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaCooley', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaCooley', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaCooley', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lisaCooley', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peteCarney', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peteCarney', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peteCarney', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peteCarney', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'peteCarney', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanCowan', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanCowan', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanCowan', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanCowan', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'seanCowan', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraForbes', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraForbes', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraForbes', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraForbes', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'lauraForbes', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaFerrell', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaFerrell', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaFerrell', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaFerrell', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaFerrell', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaDavies', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaDavies', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaDavies', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaDavies', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaDavies', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danBarajas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danBarajas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danBarajas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danBarajas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danBarajas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertShea', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertShea', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertShea', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertShea', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'robertShea', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaOsborn', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaOsborn', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaOsborn', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaOsborn', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'aliciaOsborn', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thiagoBright', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thiagoBright', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thiagoBright', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thiagoBright', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'thiagoBright', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liriCuevas', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liriCuevas', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liriCuevas', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liriCuevas', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'liriCuevas', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielBolton', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielBolton', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielBolton', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielBolton', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'danielBolton', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentMurillo', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentMurillo', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentMurillo', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentMurillo', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentMurillo', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentLutz', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentLutz', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentLutz', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentLutz', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'brentLutz', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikaDuarte', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikaDuarte', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikaDuarte', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikaDuarte', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'vikaDuarte', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shiraKidd', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shiraKidd', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shiraKidd', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shiraKidd', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'shiraKidd', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraKey', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraKey', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraKey', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraKey', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'saraKey', 5 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLis', 1 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLis', 2 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLis', 3 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLis', 4 )
GO
INSERT INTO GamesDB.[Events] VALUES ( 'mikeLis', 5 )
GO