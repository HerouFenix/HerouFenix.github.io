INSERT INTO GamesDB.[EventType] VALUES ( 'Playing' )
GO
INSERT INTO GamesDB.[EventType] VALUES ( 'WishList' )
GO
INSERT INTO GamesDB.[EventType] VALUES ( 'Plan To Play' )
GO
INSERT INTO GamesDB.[EventType] VALUES ( 'Dropped' )
GO
INSERT INTO GamesDB.[EventType] VALUES ( 'Completed' )
GO