INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESL Mistrzostwa Polski - Spring 2019: Division 2 Playoffs (CS:GO)', '2019-03-24', '2019-04-02', 'Online', 800 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Twitch Rivals Apex Legends Rematch Challenge (EU)', '2019-04-02', '2019-04-02', 'Online', 75000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Twitch Rivals Apex Legends Rematch Challenge (NA)', '2019-04-02', '2019-04-02', 'Online', 75000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESEA NA CS:GO MDL Season 30 - Playoffs', '2019-03-21', '2019-04-01', 'Online', 35000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 3, 'A&C Cup: Solo Edition', '2019-03-31', '2019-03-31', 'Online', 1130.73 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'CIS ESports Invitational', '2019-03-30', '2019-03-31', 'Online', 1500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'e-sport4u Double Elimination #34 (EU & NA)', '2019-03-31', '2019-03-31', 'Online', 200 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESEA NA CS:GO MDL Season 30 - All-Stars Game', '2019-03-31', '2019-03-31', 'Online', 6250 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESL UK/IRE Premiership - Spring 2019 (CS:GO)', '2019-01-28', '2019-03-31', 'Online/Finals: Manchester, England, UK', 17855.21 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'GG.BET AFL Frag Hunters', '2019-03-31', '2019-03-31', 'Online', 1700.41 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Go4CS:GO EU #349', '2019-03-31', '2019-03-31', 'Online', 112.31 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'GrubHub Sunday Showdown week 6', '2019-03-31', '2019-03-31', 'Online', 12345 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Luxe Cup - NA East', '2019-03-30', '2019-03-31', 'Online', 30000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Luxe Cup - NA West', '2019-03-30', '2019-03-31', 'Online', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Luxe Cup - Oceania', '2019-03-30', '2019-03-31', 'Online', 5000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Luxe Cup - South America', '2019-03-30', '2019-03-31', 'Online', 7500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Mythic Cup #1', '2019-03-31', '2019-03-31', 'Online', 1500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 6, 'Mythic Invitational', '2019-03-28', '2019-03-31', 'Boston, USA', 1000000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 3, 'Trackmania Grand League - Step 6', '2019-03-31', '2019-03-31', 'Online', 568.14 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'UML Season 1: Finals', '2019-03-30', '2019-03-31', 'Osnabr�ck, Lower Saxony, Germany', 100000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Apex Legends Challenge Asia Cup Finals', '2019-03-30', '2019-03-30', 'Online', 71500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'GG.Bet Sydney Invitational', '2019-03-25', '2019-03-30', 'Online', 5000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 7, 'MT Weekend 5x5 Cup #5', '2019-03-30', '2019-03-30', 'Online', 109.43 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'T1 x FACEIT Apex Legends Invitational', '2019-03-30', '2019-03-30', 'Online', 25000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'UMG Apex Legends Series Week 4', '2019-03-30', '2019-03-30', 'Online', 4000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'WGC 2019 Invitational', '2019-03-30', '2019-03-30', 'Nordic', 160 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'WIRE Esports Apex Legends Global 1k Invitational', '2019-03-30', '2019-03-30', 'Online', 1500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Code Red #3', '2019-03-29', '2019-03-29', 'Online', 25000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 8, 'CSW Season 2 King of the Hill (SFV AE)', '2019-03-29', '2019-03-29', 'Bahria Town,Rawalpindi,Pakistan', 4615 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESEA TR CS:GO Open Season 30 - Playoffs', '2019-03-29', '2019-03-29', 'Online', 750 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 9, 'TRUGAMING Invitational Tekken 7', '2019-03-29', '2019-03-29', 'Saudi Arabia', 95000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ESEA AU CS:GO MDL Season 30 - Playoffs', '2019-03-24', '2019-03-28', 'Online', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'FACEIT Pro League EU March Week #4 2019 (CS:GO)', '2019-03-20', '2019-03-27', 'Online', 5200 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 3, 'Trackmania University Cup', '2019-02-26', '2019-03-26', 'Online', 226.15 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Twitch Rivals Apex Legends Challenge - Road to TwitchCon (North America)', '2019-03-26', '2019-03-26', 'Online', 50000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Twitch Rivals Apex Legends Challenge Europe - Road to TwitchCon', '2019-03-26', '2019-03-26', 'Online', 49250 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Aorus League - 2019 Finals', '2019-03-24', '2019-03-24', 'S�o Paulo, Brazil', 4700 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Apex Arena Weekly #6', '2019-03-24', '2019-03-24', 'Online', 150 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - Asia', '2019-03-23', '2019-03-24', 'Online', 7500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - Europe', '2019-03-23', '2019-03-24', 'Online', 40000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - NA East', '2019-03-23', '2019-03-24', 'Online', 30000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - NA West', '2019-03-23', '2019-03-24', 'Online', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - Oceania', '2019-03-23', '2019-03-24', 'Online', 5000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Blackheart cup - South America', '2019-03-23', '2019-03-24', 'Online', 7500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 7, 'DreamLeague Season 11', '2019-03-23', '2019-03-24', 'Stockholm, Sweden', 1000000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 10, 'FB5', '2019-03-23', '2019-03-24', 'Bloomington, Indiana', 2530 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Go4CS:GO EU #348', '2019-03-24', '2019-03-24', 'Online', 112.97 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'GrubHub Sunday Showdown week 5', '2019-03-24', '2019-03-24', 'Online', 3000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'March of Legends (EU)', '2019-03-23', '2019-03-24', 'Online', 1000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 11, 'Overwatch League - Season 2 Stage 1', '2019-02-14', '2019-03-24', 'Los Angeles, United States', 500000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Strong Esports: 2k Invitational Series #2', '2019-03-24', '2019-03-24', 'Online', 2000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 12, 'XP Esports Queensland Pro AM 2019', '2019-03-23', '2019-03-24', 'Brisbane, Australia', 5325 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'A1 Gaming League Season 1', '2019-03-23', '2019-03-23', 'Sofia, Bulgaria', 3292.9 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 12, 'Asia Championship 2019', '2019-03-23', '2019-03-23', 'Hong Kong', 20000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'BLAST Pro Series: S�o Paulo 2019', '2019-03-22', '2019-03-23', 'S�o Paulo, Brazil', 230000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'BLAST Pro Series: S�o Paulo 2019 Pro Standoff', '2019-03-23', '2019-03-23', 'S�o Paulo, Brazil', 20000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 10, 'CTGamercon', '2019-03-23', '2019-03-23', 'Uncasville, Connecticut', 2871 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Dustin Expo Open', '2019-03-23', '2019-03-23', 'Stockholm, Sweden', 5385 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'e-sport4u Double Elimination #33 (EU & NA)', '2019-03-23', '2019-03-23', 'Online', 200 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 5, 'Mother of the nation festival - Fortnite tournament', '2019-03-22', '2019-03-23', 'Abu Dhabi', 13342.42 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 13, 'Oceanic Cup 2019', '2019-03-16', '2019-03-23', 'Sydney', 17750 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Stage142 2019 CS:GO', '2019-03-22', '2019-03-23', 'Jyv�skyl�, Finland', 2262.64 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'Surf League 1v1s', '2019-03-23', '2019-03-23', 'Online', 34.5 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'UMG Apex Legends Series Week 3', '2019-03-23', '2019-03-23', 'Online', 3000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 10, 'WSA: Sword', '2019-03-23', '2019-03-23', 'Waterville, ME', 660 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'XP All Stars 2v2', '2019-03-23', '2019-03-23', 'Online', 100 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'CIS ESPORTS LEAGUE CHALLANGER MARCH PART #2', '2019-03-15', '2019-03-22', 'Online', 625 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'FNB 2019 NA #2', '2019-03-22', '2019-03-22', 'Online', 100 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Strong Esports: 1k Invitational Series #2 - Qualifier', '2019-03-22', '2019-03-22', 'Online', 500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ECS S7 - Europe Series 2', '2019-03-18', '2019-03-21', 'Online', 25000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'ECS S7 - NA Series 2', '2019-03-18', '2019-03-21', 'Online', 25000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'FACEIT Pro League EU March Week #3 2019 (CS:GO)', '2019-03-13', '2019-03-20', 'Online', 5200 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'LOOT.BET Hotshot Series Season 2: CIS Qualifier', '2019-03-18', '2019-03-20', 'Online', 2500 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'LOOT.BET/CS Season 1', '2019-02-04', '2019-03-20', 'Online', 30000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'FACEIT Pro League NA 12/03 -19/03 2019 (CS:GO)', '2019-03-12', '2019-03-19', 'Online', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 2, 'Apex Arena Weekly #5', '2019-03-17', '2019-03-17', 'Online', 150 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 12, 'CWL 2019 Fort Worth', '2019-03-15', '2019-03-17', 'Fort Worth, TX', 325000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 12, 'CWL 2019 Fort Worth (Open)', '2019-03-15', '2019-03-17', 'Fort Worth, TX', 75000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'Final Round 2019 (Brawlhalla 1v1s)', '2019-03-16', '2019-03-17', 'Atlanta, USA', 660 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'Final Round 2019 (Brawlhalla 2v2s)', '2019-03-15', '2019-03-17', 'Atlanta, USA', 200 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'Final Round 2019 (Brawlhalla Doubles)', '2019-03-15', '2019-03-17', 'Atlanta, Georgia', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 4, 'Final Round 2019 (Brawlhalla Singles)', '2019-03-16', '2019-03-17', 'Atlanta, Georgia', 10000 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 14, 'Final Round 2019 (DBFZ)', '2019-03-15', '2019-03-17', 'Atlanta, USA', 1460 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 8, 'Final Round 2019 (SFV:AE)', '2019-03-15', '2019-03-17', 'Atlanta, USA', 18270 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 10, 'Final Round 2019 (SSBU Singles)', '2019-03-16', '2019-03-17', 'Atlanta, USA', 1600 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 9, 'Final Round 2019 (T7)', '2019-03-15', '2019-03-17', 'Atlanta, USA', 2960 )
GO
INSERT INTO GamesDB.[Tournments] VALUES ( 1, 'Go4CS:GO EU #347', '2019-03-17', '2019-03-17', 'Online', 113.27 )
GO