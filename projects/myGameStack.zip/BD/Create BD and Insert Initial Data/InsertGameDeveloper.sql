INSERT INTO GamesDB.[GameDeveloper] VALUES ( 1, 1 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 1, 2 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 2, 3 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 3, 4 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 4, 5 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 5, 6 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 6, 7 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 7, 1 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 8, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 9, 9 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 10, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 11, 11 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 12, 12 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 12, 13 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 12, 14 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 13, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 14, 16 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 15, 17 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 16, 17 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 17, 17 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 18, 18 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 19, 17 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 20, 19 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 21, 19 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 22, 19 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 22, 20 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 23, 21 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 23, 22 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 24, 21 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 25, 21 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 26, 21 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 27, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 28, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 29, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 30, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 31, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 32, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 33, 8 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 34, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 35, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 36, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 37, 24 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 38, 25 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 39, 25 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 40, 25 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 41, 25 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 42, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 43, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 44, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 45, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 46, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 47, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 48, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 49, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 50, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 51, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 52, 15 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 53, 26 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 54, 26 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 55, 26 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 56, 26 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 57, 26 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 58, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 59, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 60, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 61, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 62, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 63, 23 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 64, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 65, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 66, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 67, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 68, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 69, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 70, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 71, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 72, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 73, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 74, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 75, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 76, 10 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 77, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 78, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 79, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 80, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 81, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 82, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 83, 27 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 84, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 85, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 86, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 87, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 88, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 89, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 90, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 91, 28 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 92, 29 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 93, 29 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 94, 30 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 95, 30 )
GO
INSERT INTO GamesDB.[GameDeveloper] VALUES ( 96, 30 )
GO