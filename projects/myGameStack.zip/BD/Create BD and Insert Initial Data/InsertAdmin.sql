insert into GamesDB.[Admin] values ('admin1', '2019-05-17');
go
insert into GamesDB.[Admin] values ('admin2', '2019-05-18');
go
insert into GamesDB.[Admin] values ('admin3', '2019-05-18');
go