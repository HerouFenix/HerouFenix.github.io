﻿namespace GamesDB
{
    partial class admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox_users = new System.Windows.Forms.GroupBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_regist_user = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_userName = new System.Windows.Forms.TextBox();
            this.panel_signUp = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_photo = new System.Windows.Forms.TextBox();
            this.textBox_lName = new System.Windows.Forms.TextBox();
            this.textBox_fName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_email = new System.Windows.Forms.TextBox();
            this.button_loadImage = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button21 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.button22 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button23 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button25 = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button29 = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.button31 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.button30 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.groupBox_users.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_signUp.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(294, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "Game ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 35;
            this.label2.Text = "User Name";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(234, 179);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(205, 44);
            this.richTextBox3.TabIndex = 30;
            this.richTextBox3.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(234, 74);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(205, 44);
            this.richTextBox1.TabIndex = 28;
            this.richTextBox1.Text = "";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(33, 158);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(154, 72);
            this.button6.TabIndex = 25;
            this.button6.Text = "Remove User";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(33, 52);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 72);
            this.button2.TabIndex = 23;
            this.button2.Text = "Promote User to Admin";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox_users
            // 
            this.groupBox_users.Controls.Add(this.richTextBox2);
            this.groupBox_users.Controls.Add(this.label7);
            this.groupBox_users.Controls.Add(this.button2);
            this.groupBox_users.Controls.Add(this.button6);
            this.groupBox_users.Controls.Add(this.richTextBox1);
            this.groupBox_users.Controls.Add(this.label2);
            this.groupBox_users.Location = new System.Drawing.Point(18, 19);
            this.groupBox_users.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_users.Name = "groupBox_users";
            this.groupBox_users.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_users.Size = new System.Drawing.Size(477, 275);
            this.groupBox_users.TabIndex = 42;
            this.groupBox_users.TabStop = false;
            this.groupBox_users.Text = "Users";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(234, 179);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(205, 44);
            this.richTextBox2.TabIndex = 36;
            this.richTextBox2.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(294, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 20);
            this.label7.TabIndex = 37;
            this.label7.Text = "User Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.richTextBox3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(18, 320);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(477, 275);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Games";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(33, 52);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(408, 72);
            this.button1.TabIndex = 23;
            this.button1.Text = "Add Game";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(33, 158);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(154, 72);
            this.button7.TabIndex = 25;
            this.button7.Text = "Remove Game";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.richTextBox4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(18, 641);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(477, 275);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Franchises";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(33, 52);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(408, 72);
            this.button4.TabIndex = 23;
            this.button4.Text = "Add Franchise";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(33, 158);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(154, 72);
            this.button5.TabIndex = 25;
            this.button5.Text = "Remove Franchise";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(234, 179);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(205, 44);
            this.richTextBox4.TabIndex = 30;
            this.richTextBox4.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(294, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "Franchise ID";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.richTextBox5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(536, 19);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(477, 275);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Developers";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(33, 52);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(408, 72);
            this.button8.TabIndex = 23;
            this.button8.Text = "Add Developer";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(33, 158);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(154, 72);
            this.button9.TabIndex = 25;
            this.button9.Text = "Remove Developer";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(234, 179);
            this.richTextBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(205, 44);
            this.richTextBox5.TabIndex = 30;
            this.richTextBox5.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(294, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 20);
            this.label4.TabIndex = 36;
            this.label4.Text = "Developer ID";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.button11);
            this.groupBox4.Controls.Add(this.richTextBox6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(536, 320);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Size = new System.Drawing.Size(477, 275);
            this.groupBox4.TabIndex = 46;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Publishers";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(33, 52);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(408, 72);
            this.button10.TabIndex = 23;
            this.button10.Text = "Add Publisher";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(33, 158);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(154, 72);
            this.button11.TabIndex = 25;
            this.button11.Text = "Remove Publisher";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // richTextBox6
            // 
            this.richTextBox6.Location = new System.Drawing.Point(234, 179);
            this.richTextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(205, 44);
            this.richTextBox6.TabIndex = 30;
            this.richTextBox6.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(294, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Publisher ID";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button12);
            this.groupBox5.Controls.Add(this.button13);
            this.groupBox5.Controls.Add(this.richTextBox7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Location = new System.Drawing.Point(536, 641);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Size = new System.Drawing.Size(477, 275);
            this.groupBox5.TabIndex = 47;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tournments";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(33, 52);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(408, 72);
            this.button12.TabIndex = 23;
            this.button12.Text = "Add Tournment";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(33, 158);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(154, 72);
            this.button13.TabIndex = 25;
            this.button13.Text = "Remove Tournment";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(234, 179);
            this.richTextBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(205, 44);
            this.richTextBox7.TabIndex = 30;
            this.richTextBox7.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(294, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 20);
            this.label6.TabIndex = 36;
            this.label6.Text = "Tournment ID";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button14);
            this.groupBox6.Controls.Add(this.button15);
            this.groupBox6.Controls.Add(this.richTextBox8);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Location = new System.Drawing.Point(1050, 19);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Size = new System.Drawing.Size(477, 275);
            this.groupBox6.TabIndex = 46;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Genres";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(33, 52);
            this.button14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(408, 72);
            this.button14.TabIndex = 23;
            this.button14.Text = "Add Genre";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(33, 158);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(154, 72);
            this.button15.TabIndex = 25;
            this.button15.Text = "Remove Genre";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // richTextBox8
            // 
            this.richTextBox8.Location = new System.Drawing.Point(234, 179);
            this.richTextBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(205, 44);
            this.richTextBox8.TabIndex = 30;
            this.richTextBox8.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(294, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 20);
            this.label8.TabIndex = 36;
            this.label8.Text = "Genre ID";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button16);
            this.groupBox7.Controls.Add(this.button17);
            this.groupBox7.Controls.Add(this.richTextBox9);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Location = new System.Drawing.Point(1050, 320);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Size = new System.Drawing.Size(477, 275);
            this.groupBox7.TabIndex = 47;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Platforms";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(33, 52);
            this.button16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(408, 72);
            this.button16.TabIndex = 23;
            this.button16.Text = "Add Platform";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(33, 158);
            this.button17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(154, 72);
            this.button17.TabIndex = 25;
            this.button17.Text = "Remove Platform";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // richTextBox9
            // 
            this.richTextBox9.Location = new System.Drawing.Point(234, 179);
            this.richTextBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(205, 44);
            this.richTextBox9.TabIndex = 30;
            this.richTextBox9.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(294, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 20);
            this.label9.TabIndex = 36;
            this.label9.Text = "Platform ID";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_regist_user);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.textBox_userName);
            this.panel1.Location = new System.Drawing.Point(3, 9);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1537, 1032);
            this.panel1.TabIndex = 48;
            this.panel1.Visible = false;
            // 
            // button_regist_user
            // 
            this.button_regist_user.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button_regist_user.Location = new System.Drawing.Point(903, 568);
            this.button_regist_user.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button_regist_user.Name = "button_regist_user";
            this.button_regist_user.Size = new System.Drawing.Size(122, 66);
            this.button_regist_user.TabIndex = 22;
            this.button_regist_user.Text = "Confirm";
            this.button_regist_user.UseVisualStyleBackColor = true;
            this.button_regist_user.Click += new System.EventHandler(this.button_regist_user_Click);
            // 
            // button18
            // 
            this.button18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button18.Location = new System.Drawing.Point(447, 568);
            this.button18.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(124, 66);
            this.button18.TabIndex = 23;
            this.button18.Text = "Go Back";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(468, 472);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 20);
            this.label16.TabIndex = 20;
            this.label16.Text = "Genre Name:";
            // 
            // textBox_userName
            // 
            this.textBox_userName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_userName.Location = new System.Drawing.Point(730, 470);
            this.textBox_userName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox_userName.Name = "textBox_userName";
            this.textBox_userName.Size = new System.Drawing.Size(229, 26);
            this.textBox_userName.TabIndex = 21;
            // 
            // panel_signUp
            // 
            this.panel_signUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_signUp.Controls.Add(this.button19);
            this.panel_signUp.Controls.Add(this.tableLayoutPanel1);
            this.panel_signUp.Controls.Add(this.button20);
            this.panel_signUp.Location = new System.Drawing.Point(381, 36);
            this.panel_signUp.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel_signUp.Name = "panel_signUp";
            this.panel_signUp.Size = new System.Drawing.Size(764, 889);
            this.panel_signUp.TabIndex = 13;
            // 
            // button19
            // 
            this.button19.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button19.Location = new System.Drawing.Point(449, 730);
            this.button19.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(122, 66);
            this.button19.TabIndex = 8;
            this.button19.Text = "Confirm";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button_regist_developer_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.7957F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.2043F));
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox_photo, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox_lName, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox_fName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox_email, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_loadImage, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 1, 5);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 98);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(764, 550);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox2.Location = new System.Drawing.Point(253, 487);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(229, 26);
            this.textBox2.TabIndex = 21;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(179, 490);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 20);
            this.label15.TabIndex = 20;
            this.label15.Text = "Country:";
            // 
            // textBox_photo
            // 
            this.textBox_photo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_photo.Location = new System.Drawing.Point(253, 324);
            this.textBox_photo.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox_photo.Name = "textBox_photo";
            this.textBox_photo.Size = new System.Drawing.Size(229, 26);
            this.textBox_photo.TabIndex = 15;
            // 
            // textBox_lName
            // 
            this.textBox_lName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_lName.Location = new System.Drawing.Point(253, 249);
            this.textBox_lName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox_lName.Name = "textBox_lName";
            this.textBox_lName.Size = new System.Drawing.Size(229, 26);
            this.textBox_lName.TabIndex = 12;
            // 
            // textBox_fName
            // 
            this.textBox_fName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_fName.Location = new System.Drawing.Point(253, 174);
            this.textBox_fName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox_fName.Name = "textBox_fName";
            this.textBox_fName.Size = new System.Drawing.Size(229, 26);
            this.textBox_fName.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(208, 402);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 20);
            this.label10.TabIndex = 7;
            this.label10.Text = "City:";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(176, 252);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 20);
            this.label11.TabIndex = 4;
            this.label11.Text = "Website:";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(191, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Email :";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(188, 177);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 20);
            this.label13.TabIndex = 3;
            this.label13.Text = "Phone:";
            // 
            // textBox_email
            // 
            this.textBox_email.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_email.Location = new System.Drawing.Point(253, 99);
            this.textBox_email.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox_email.Name = "textBox_email";
            this.textBox_email.Size = new System.Drawing.Size(229, 26);
            this.textBox_email.TabIndex = 8;
            // 
            // button_loadImage
            // 
            this.button_loadImage.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button_loadImage.Location = new System.Drawing.Point(165, 320);
            this.button_loadImage.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button_loadImage.Name = "button_loadImage";
            this.button_loadImage.Size = new System.Drawing.Size(82, 35);
            this.button_loadImage.TabIndex = 16;
            this.button_loadImage.Text = "Image";
            this.button_loadImage.UseVisualStyleBackColor = true;
            this.button_loadImage.Click += new System.EventHandler(this.button_loadImage_Developer);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(116, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 20);
            this.label14.TabIndex = 18;
            this.label14.Text = "Developer Name:";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox1.Location = new System.Drawing.Point(253, 24);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(229, 26);
            this.textBox1.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox3.Location = new System.Drawing.Point(253, 399);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(229, 26);
            this.textBox3.TabIndex = 14;
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button20.Location = new System.Drawing.Point(178, 730);
            this.button20.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(124, 66);
            this.button20.TabIndex = 9;
            this.button20.Text = "Go Back";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel_signUp);
            this.panel2.Location = new System.Drawing.Point(10, 5);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1527, 960);
            this.panel2.TabIndex = 49;
            this.panel2.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(10, 5);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1527, 964);
            this.panel3.TabIndex = 51;
            this.panel3.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.tableLayoutPanel2);
            this.panel4.Controls.Add(this.button23);
            this.panel4.Location = new System.Drawing.Point(381, 38);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(764, 889);
            this.panel4.TabIndex = 13;
            // 
            // button21
            // 
            this.button21.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button21.Location = new System.Drawing.Point(449, 730);
            this.button21.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(122, 66);
            this.button21.TabIndex = 8;
            this.button21.Text = "Confirm";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button_regist_Publisher_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.7957F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.2043F));
            this.tableLayoutPanel2.Controls.Add(this.textBox4, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label17, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.textBox5, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.textBox6, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.textBox7, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label18, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label20, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label21, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.textBox8, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.button22, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBox9, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBox10, 1, 5);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 98);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(764, 550);
            this.tableLayoutPanel2.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox4.Location = new System.Drawing.Point(253, 487);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(229, 26);
            this.textBox4.TabIndex = 21;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(179, 490);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 20);
            this.label17.TabIndex = 20;
            this.label17.Text = "Country:";
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox5.Location = new System.Drawing.Point(253, 324);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(229, 26);
            this.textBox5.TabIndex = 15;
            // 
            // textBox6
            // 
            this.textBox6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox6.Location = new System.Drawing.Point(253, 249);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(229, 26);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox7.Location = new System.Drawing.Point(253, 174);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(229, 26);
            this.textBox7.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(208, 402);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 20);
            this.label18.TabIndex = 7;
            this.label18.Text = "City:";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(176, 252);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 20);
            this.label19.TabIndex = 4;
            this.label19.Text = "Website:";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(191, 102);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Email :";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(188, 177);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 20);
            this.label21.TabIndex = 3;
            this.label21.Text = "Phone:";
            // 
            // textBox8
            // 
            this.textBox8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox8.Location = new System.Drawing.Point(253, 99);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(229, 26);
            this.textBox8.TabIndex = 8;
            // 
            // button22
            // 
            this.button22.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button22.Location = new System.Drawing.Point(165, 320);
            this.button22.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(82, 35);
            this.button22.TabIndex = 16;
            this.button22.Text = "Image";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button_loadImage_ClickPublisher);
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(123, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(124, 20);
            this.label22.TabIndex = 18;
            this.label22.Text = "Publisher Name:";
            // 
            // textBox9
            // 
            this.textBox9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox9.Location = new System.Drawing.Point(253, 24);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(229, 26);
            this.textBox9.TabIndex = 19;
            // 
            // textBox10
            // 
            this.textBox10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox10.Location = new System.Drawing.Point(253, 399);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(229, 26);
            this.textBox10.TabIndex = 14;
            // 
            // button23
            // 
            this.button23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button23.Location = new System.Drawing.Point(178, 730);
            this.button23.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(124, 66);
            this.button23.TabIndex = 9;
            this.button23.Text = "Go Back";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.Controls.Add(this.button24);
            this.panel6.Controls.Add(this.tableLayoutPanel3);
            this.panel6.Controls.Add(this.button26);
            this.panel6.Location = new System.Drawing.Point(385, 30);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(764, 889);
            this.panel6.TabIndex = 13;
            // 
            // button24
            // 
            this.button24.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button24.Location = new System.Drawing.Point(449, 730);
            this.button24.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(122, 66);
            this.button24.TabIndex = 8;
            this.button24.Text = "Confirm";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button_regist_platfrom_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.7957F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.2043F));
            this.tableLayoutPanel3.Controls.Add(this.textBox14, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label26, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label27, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.textBox15, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBox16, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 98);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 7;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.80278F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.29002F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.058F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1.856148F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.048724F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.944315F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(764, 550);
            this.tableLayoutPanel3.TabIndex = 8;
            // 
            // textBox14
            // 
            this.textBox14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox14.Location = new System.Drawing.Point(253, 377);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(229, 26);
            this.textBox14.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(107, 245);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(140, 20);
            this.label26.TabIndex = 0;
            this.label26.Text = "Manufactor Name:";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(136, 380);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(111, 20);
            this.label27.TabIndex = 3;
            this.label27.Text = "Release Date:";
            // 
            // textBox15
            // 
            this.textBox15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox15.Location = new System.Drawing.Point(253, 242);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(229, 26);
            this.textBox15.TabIndex = 8;
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(129, 83);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(118, 20);
            this.label28.TabIndex = 18;
            this.label28.Text = "Platform Name:";
            // 
            // textBox16
            // 
            this.textBox16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox16.Location = new System.Drawing.Point(253, 80);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(229, 26);
            this.textBox16.TabIndex = 19;
            // 
            // button26
            // 
            this.button26.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button26.Location = new System.Drawing.Point(178, 730);
            this.button26.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(124, 66);
            this.button26.TabIndex = 9;
            this.button26.Text = "Go Back";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(7, 5);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1533, 948);
            this.panel5.TabIndex = 52;
            this.panel5.Visible = false;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.Controls.Add(this.button25);
            this.panel8.Controls.Add(this.tableLayoutPanel4);
            this.panel8.Controls.Add(this.button28);
            this.panel8.Location = new System.Drawing.Point(381, 30);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(764, 889);
            this.panel8.TabIndex = 13;
            // 
            // button25
            // 
            this.button25.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button25.Location = new System.Drawing.Point(449, 730);
            this.button25.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(122, 66);
            this.button25.TabIndex = 8;
            this.button25.Text = "Confirm";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button_regist_franchise_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.7957F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.2043F));
            this.tableLayoutPanel4.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox19, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox12, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.button27, 0, 2);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 98);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 7;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.58878F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.04673F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.12149F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.278688F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.112676F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1.877934F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 14F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(764, 550);
            this.tableLayoutPanel4.TabIndex = 8;
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(118, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(129, 20);
            this.label31.TabIndex = 18;
            this.label31.Text = "Franchise Name:";
            // 
            // textBox19
            // 
            this.textBox19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox19.Location = new System.Drawing.Point(253, 98);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(229, 26);
            this.textBox19.TabIndex = 19;
            // 
            // textBox12
            // 
            this.textBox12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox12.Location = new System.Drawing.Point(253, 372);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(229, 26);
            this.textBox12.TabIndex = 15;
            // 
            // button27
            // 
            this.button27.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button27.Location = new System.Drawing.Point(165, 367);
            this.button27.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(82, 35);
            this.button27.TabIndex = 16;
            this.button27.Text = "Image";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button_loadImage_Click_Franchise);
            // 
            // button28
            // 
            this.button28.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button28.Location = new System.Drawing.Point(178, 730);
            this.button28.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(124, 66);
            this.button28.TabIndex = 9;
            this.button28.Text = "Go Back";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(7, 1);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1527, 948);
            this.panel7.TabIndex = 53;
            this.panel7.Visible = false;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel10.Controls.Add(this.button29);
            this.panel10.Controls.Add(this.tableLayoutPanel5);
            this.panel10.Controls.Add(this.button31);
            this.panel10.Location = new System.Drawing.Point(381, 21);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(764, 889);
            this.panel10.TabIndex = 13;
            // 
            // button29
            // 
            this.button29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button29.Location = new System.Drawing.Point(449, 730);
            this.button29.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(122, 66);
            this.button29.TabIndex = 8;
            this.button29.Text = "Confirm";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.regist_tournment);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.7957F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.2043F));
            this.tableLayoutPanel5.Controls.Add(this.label33, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.textBox17, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.textBox18, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.label24, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.label25, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label29, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label30, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.textBox20, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.label32, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.textBox21, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.textBox13, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.comboBox7, 1, 5);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 98);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 7;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.64706F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.88235F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.11765F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.94118F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.411765F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(764, 550);
            this.tableLayoutPanel5.TabIndex = 8;
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(169, 415);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(78, 20);
            this.label33.TabIndex = 15;
            this.label33.Text = "End date:";
            // 
            // textBox17
            // 
            this.textBox17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox17.Location = new System.Drawing.Point(253, 309);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(229, 26);
            this.textBox17.TabIndex = 12;
            // 
            // textBox18
            // 
            this.textBox18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox18.Location = new System.Drawing.Point(253, 218);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(229, 26);
            this.textBox18.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(190, 496);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 20);
            this.label24.TabIndex = 7;
            this.label24.Text = "Game:";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(163, 312);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(84, 20);
            this.label25.TabIndex = 4;
            this.label25.Text = "Start date:";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(164, 131);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 20);
            this.label29.TabIndex = 0;
            this.label29.Text = "Prize Pool:";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(173, 221);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(74, 20);
            this.label30.TabIndex = 3;
            this.label30.Text = "Location:";
            // 
            // textBox20
            // 
            this.textBox20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox20.Location = new System.Drawing.Point(253, 128);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(229, 26);
            this.textBox20.TabIndex = 8;
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(111, 37);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(136, 20);
            this.label32.TabIndex = 18;
            this.label32.Text = "Tournment Name:";
            // 
            // textBox21
            // 
            this.textBox21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox21.Location = new System.Drawing.Point(253, 34);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(229, 26);
            this.textBox21.TabIndex = 19;
            // 
            // textBox13
            // 
            this.textBox13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox13.Location = new System.Drawing.Point(253, 412);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(229, 26);
            this.textBox13.TabIndex = 16;
            // 
            // comboBox7
            // 
            this.comboBox7.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "None"});
            this.comboBox7.Location = new System.Drawing.Point(253, 487);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(163, 28);
            this.comboBox7.TabIndex = 30;
            // 
            // button31
            // 
            this.button31.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button31.Location = new System.Drawing.Point(178, 730);
            this.button31.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(124, 66);
            this.button31.TabIndex = 9;
            this.button31.Text = "Go Back";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Location = new System.Drawing.Point(3, 1);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1527, 930);
            this.panel9.TabIndex = 54;
            this.panel9.Visible = false;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.Controls.Add(this.button36);
            this.panel12.Controls.Add(this.button37);
            this.panel12.Controls.Add(this.comboBox6);
            this.panel12.Controls.Add(this.label40);
            this.panel12.Controls.Add(this.textBox11);
            this.panel12.Controls.Add(this.comboBox5);
            this.panel12.Controls.Add(this.button39);
            this.panel12.Controls.Add(this.button38);
            this.panel12.Controls.Add(this.button34);
            this.panel12.Controls.Add(this.button35);
            this.panel12.Controls.Add(this.label23);
            this.panel12.Controls.Add(this.comboBox4);
            this.panel12.Controls.Add(this.textBox24);
            this.panel12.Controls.Add(this.button30);
            this.panel12.Controls.Add(this.label34);
            this.panel12.Controls.Add(this.textBox23);
            this.panel12.Controls.Add(this.textBox27);
            this.panel12.Controls.Add(this.label39);
            this.panel12.Controls.Add(this.textBox22);
            this.panel12.Controls.Add(this.button32);
            this.panel12.Controls.Add(this.button33);
            this.panel12.Controls.Add(this.label35);
            this.panel12.Controls.Add(this.comboBox3);
            this.panel12.Controls.Add(this.textBox26);
            this.panel12.Controls.Add(this.label36);
            this.panel12.Controls.Add(this.comboBox2);
            this.panel12.Controls.Add(this.label37);
            this.panel12.Controls.Add(this.label38);
            this.panel12.Controls.Add(this.textBox25);
            this.panel12.Location = new System.Drawing.Point(384, 15);
            this.panel12.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(760, 889);
            this.panel12.TabIndex = 13;
            // 
            // button36
            // 
            this.button36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button36.Location = new System.Drawing.Point(675, 422);
            this.button36.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(62, 29);
            this.button36.TabIndex = 58;
            this.button36.Text = "Add";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button37.Location = new System.Drawing.Point(675, 312);
            this.button37.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(62, 99);
            this.button37.TabIndex = 57;
            this.button37.Text = "X";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // comboBox6
            // 
            this.comboBox6.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "None"});
            this.comboBox6.Location = new System.Drawing.Point(159, 422);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(512, 28);
            this.comboBox6.TabIndex = 56;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(58, 335);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(90, 20);
            this.label40.TabIndex = 54;
            this.label40.Text = "Platform(s):";
            // 
            // textBox11
            // 
            this.textBox11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox11.Enabled = false;
            this.textBox11.Location = new System.Drawing.Point(159, 312);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(512, 98);
            this.textBox11.TabIndex = 55;
            // 
            // comboBox5
            // 
            this.comboBox5.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "None"});
            this.comboBox5.Location = new System.Drawing.Point(159, 619);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(562, 28);
            this.comboBox5.TabIndex = 53;
            // 
            // button39
            // 
            this.button39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button39.Location = new System.Drawing.Point(675, 212);
            this.button39.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(62, 29);
            this.button39.TabIndex = 52;
            this.button39.Text = "Add";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button38
            // 
            this.button38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button38.Location = new System.Drawing.Point(675, 571);
            this.button38.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(62, 29);
            this.button38.TabIndex = 52;
            this.button38.Text = "Add";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button34
            // 
            this.button34.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button34.Location = new System.Drawing.Point(675, 142);
            this.button34.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(62, 60);
            this.button34.TabIndex = 49;
            this.button34.Text = "X";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button35.Location = new System.Drawing.Point(675, 460);
            this.button35.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(62, 99);
            this.button35.TabIndex = 48;
            this.button35.Text = "X";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(53, 625);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 20);
            this.label23.TabIndex = 42;
            this.label23.Text = "Franchise:";
            // 
            // comboBox4
            // 
            this.comboBox4.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "None"});
            this.comboBox4.Location = new System.Drawing.Point(159, 570);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(512, 28);
            this.comboBox4.TabIndex = 45;
            // 
            // textBox24
            // 
            this.textBox24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox24.Location = new System.Drawing.Point(159, 671);
            this.textBox24.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox24.Multiline = true;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(581, 92);
            this.textBox24.TabIndex = 23;
            // 
            // button30
            // 
            this.button30.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button30.Location = new System.Drawing.Point(616, 791);
            this.button30.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(122, 66);
            this.button30.TabIndex = 8;
            this.button30.Text = "Confirm";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button_regist_Game);
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(58, 482);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(76, 20);
            this.label34.TabIndex = 36;
            this.label34.Text = "Genre(s):";
            // 
            // textBox23
            // 
            this.textBox23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox23.Enabled = false;
            this.textBox23.Location = new System.Drawing.Point(159, 460);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(512, 98);
            this.textBox23.TabIndex = 38;
            // 
            // textBox27
            // 
            this.textBox27.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox27.Enabled = false;
            this.textBox27.Location = new System.Drawing.Point(159, 141);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox27.Multiline = true;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(512, 62);
            this.textBox27.TabIndex = 39;
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(46, 688);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(93, 20);
            this.label39.TabIndex = 22;
            this.label39.Text = "Description:";
            // 
            // textBox22
            // 
            this.textBox22.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox22.Location = new System.Drawing.Point(159, 261);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(562, 26);
            this.textBox22.TabIndex = 31;
            // 
            // button32
            // 
            this.button32.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button32.Location = new System.Drawing.Point(54, 260);
            this.button32.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(82, 35);
            this.button32.TabIndex = 32;
            this.button32.Text = "Image";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button_loadImage_Click_Games);
            // 
            // button33
            // 
            this.button33.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button33.Location = new System.Drawing.Point(253, 786);
            this.button33.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(124, 66);
            this.button33.TabIndex = 9;
            this.button33.Text = "Go Back";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(32, 149);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(103, 20);
            this.label35.TabIndex = 35;
            this.label35.Text = "Developer(s):";
            // 
            // comboBox3
            // 
            this.comboBox3.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "None"});
            this.comboBox3.Location = new System.Drawing.Point(159, 212);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(512, 28);
            this.comboBox3.TabIndex = 30;
            // 
            // textBox26
            // 
            this.textBox26.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox26.Location = new System.Drawing.Point(159, 18);
            this.textBox26.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(562, 26);
            this.textBox26.TabIndex = 41;
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(32, 64);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(105, 20);
            this.label36.TabIndex = 33;
            this.label36.Text = "Launch Date:";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "None"});
            this.comboBox2.Location = new System.Drawing.Point(159, 95);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(562, 28);
            this.comboBox2.TabIndex = 44;
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(56, 102);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(78, 20);
            this.label37.TabIndex = 34;
            this.label37.Text = "Publisher:";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(34, 22);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(103, 20);
            this.label38.TabIndex = 40;
            this.label38.Text = "Game Name:";
            // 
            // textBox25
            // 
            this.textBox25.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox25.Location = new System.Drawing.Point(159, 58);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(562, 26);
            this.textBox25.TabIndex = 37;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Location = new System.Drawing.Point(0, 1);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1527, 919);
            this.panel11.TabIndex = 55;
            this.panel11.Visible = false;
            // 
            // admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1698, 968);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_users);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "admin";
            this.Text = "Administrator";
            this.Load += new System.EventHandler(this.admin_Load_1);
            this.groupBox_users.ResumeLayout(false);
            this.groupBox_users.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_signUp.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox_users;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_userName;
        private System.Windows.Forms.Button button_regist_user;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel panel_signUp;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_photo;
        private System.Windows.Forms.TextBox textBox_lName;
        private System.Windows.Forms.TextBox textBox_fName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_email;
        private System.Windows.Forms.Button button_loadImage;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox11;
    }
}