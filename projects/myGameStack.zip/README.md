# BD_Projeto
Projeto de BD: sql scripts and other necessary stuff
