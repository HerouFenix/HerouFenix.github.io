function guitar(){
	this.x = width/2;
	this.y = height-100;
	this.expand = false;
	this.hit = false;
	this.score = 0;

	this.show = function(){
		stroke(255);
		noFill();
		if (this.expand){
			if (this.hit){
				stroke(0,0,255);
				this.hit = false;
			}else{
				stroke(255,0,0);
			}
			rect(this.x-40,this.y-20,80,80);
			this.expand = false;
		}else{
			rect(this.x-20,this.y,40,40);
		}
	}

	this.pluck = function(notes){
		this.expand = true;
		for (var i = notes.length-1; i>=0;i--){
			if (notes[i].x === this.x){
				if (notes[i].y >= this.y-20 && notes[i].y <= this.y-20+80){
					console.log('Hit');
					notes.splice(i,1);
					this.score=1
					this.hit = true;
				}
			}
		}
		if (this.hit===false){
			this.score=-1
		}

	}

	this.scoreCounter = function(){
		return this.score;
	}

	this.dir = function(x){
		this.x += x;
		this.x = constrain(this.x,40,width-40);
	}

}

function lines(){
	this.x = width/2;
	this.show = function(){
		stroke(0);
		line(this.x,0,this.x,height);
		line(this.x-80,0,this.x-80,height);
		line(this.x-160,0,this.x-160,height);
		line(this.x+80,0,this.x+80,height);
		line(this.x+160,0,this.x+160,height);
	}


}