function note(){
	this.positions = [-160,-80,0,80,160];
	this.x = width/2 + this.positions[floor(random(5))];
	this.yspeed = 8;
	this.y=0;
	this.score = 0;
	this.notCounted = true;

	this.show = function(){
		noFill();
		if (this.y > height-35){
			stroke(255,0,0);
		}else{
			stroke(255);
		}
		ellipse(this.x,this.y,35,35);
	}

	this.scoreCounter = function(){
		return this.score;
		
	}

	this.update = function(guitar){
		this.y += this.yspeed;
	}

	this.finish = function(){
		if (this.y>height+70){
			this.score=-1
			return true;
		}
	}
}