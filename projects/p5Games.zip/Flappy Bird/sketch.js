var bird;
var pipes = [];

function setup() {
  createCanvas(400,600);
  bird = new bird();
  pipes.push(new pipe());
}

function draw() {
  background(51);
  bird.show();
  bird.update();

  if (frameCount%80 == 0){
  	pipes.push(new pipe());
  }

  for (var i = pipes.length-1; i >= 0; i--){
  	pipes[i].show();
  	pipes[i].update();
  	if (pipes[i].finish()){
  		pipes.splice(i,1);
  	}

  	if (pipes[i].hits(bird)){
  	}
  }
}

///////////////////////////////////////////
function bird(){
	this.x = 50;
	this.y = width/2;

	this.gravity = 0.6;
	this.lift = -15
	this.velocity = 0;

	this.show = function(){
		fill(255);
		ellipse(this.x,this.y,20,20);
	}

	this.up = function(){
		this.velocity += this.lift;
	}

	this.update = function(){
		this.velocity += this.gravity;
		this.velocity *= 0.9;
		this.y += this.velocity;

		this.y = constrain(this.y,0+10,height-10);
	}
}

function keyPressed(){
	if (keyCode === UP_ARROW){
		bird.up();
	}
}

//////////////////////////////////////////s

function pipe(){
	this.x = width;
	this.highlight = false;
	this.dist = 60;
	this.speed = 3;
	this.start = floor(random(height));
	while (this.start<60||this.start>540){
		this.start = floor(random(height));
	}

	this.top = this.start-this.dist
	this.bottom = (this.start+this.dist)-height

	this.hits = function(bird){
		if (bird.y-15<=this.top || bird.y+15>=this.bottom+height){
			if (bird.x>this.x && bird.x<this.x+30){
				this.highlight = true;
				return true;
			}
		}
	}

	this.show = function(){
		fill(255);
		if (this.highlight){
			fill(255,0,0);
		}
		//Bottom
		rect(this.x,height,25,this.bottom);
		//Top
		rect(this.x,0,25,this.top);

	}

	this.update = function(){
		this.x -= this.speed
	}

	this.finish = function(){
		if (this.x<-30){
			return true;
		}
	}
}