///////////////////Bullet

function bullet(x){
	this.y = 600+10;
	this.x = x
	this.speed = -25

	this.show = function(){
		fill(255);
		rect(this.x+27,this.y-30,5,10);

	}
	this.update = function(){
		this.y = this.y + this.speed;
	}

	this.finish = function(){
		if (this.y === -10){
			return true;
		}
	}

	this.hit = function(alien){
		if((this.y<=alien.y+20 && this.y>=alien.y-40)&&(this.x>=alien.x-40 && this.x<=alien.x-20)){
			return true
		}
	}
}