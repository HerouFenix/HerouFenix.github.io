//MineSweeper
let ship;
let bullets = [];
let aliens = [];

function setup() {
	createCanvas(500,650);
	frameRate(30);
	ship = new shipMaker();

	let xPos = width-40;
	let yPos = 30
	for (let n = 0; n<3; n++){
  		for (let m = 0; m<=6; m++){
			aliens.push(new alien(xPos,yPos));
			console.log(xPos);
			xPos = xPos - 40;
  		}
		xPos = width - 40;
		yPos = yPos + 40;
  	}
}

function draw() {
	background(51);

	ship.moveShip();
	ship.show();

	for (let i = bullets.length-1; i >= 0; i--){
		let bullet = bullets[i];
		bullet.show();
  		bullet.update();
  		if (bullet.finish()){
   			bullets.splice(i,1);
  		}
  		for (let j = aliens.length-1; j>=0; j--){
  			if(bullet.hit(aliens[j])){
   				bullets.splice(i,1);
   				aliens[j].life--
   				if (aliens[j].life == -1)
   			   		aliens.splice(j,1);
  			}
  		}
  	}

  	let edge = false;
  	for (let i = aliens.length-1; i >= 0; i--){
  		aliens[i].show();
  		aliens[i].update();
  		if(aliens[i].checkWall()){
  			edge = true;
  		}
  	}
  	if (edge){
  		for (let i = aliens.length-1; i>=0; i--){
  			aliens[i].moveDown();
  		}
  	}
}

function keyReleased(){
	if (keyCode!= UP_ARROW){
		ship.xSpeed = 0
	}
}


function keyPressed(){
	if (keyCode === LEFT_ARROW){
		ship.xSpeed = -3;
	}else if (keyCode === RIGHT_ARROW){
		ship.xSpeed = 3;
	}

	if (keyCode === UP_ARROW){
		bullets.push(new bullet(ship.x));
	}
}
