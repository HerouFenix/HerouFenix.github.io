//Minesweeper
var grid;
var res = 40;
var cols;
var rows;
var totalBombs = 10;
var bombLocations = [];

function make2DArray(rows,cols){
	var myArray = new Array(rows);
	for (var i = 0; i < myArray.length; i++){
		myArray[i] = new Array(cols);
	}
	return myArray;
}

function setup() {
	createCanvas(401,401);
	cols = floor(width/res);
	rows = floor(height/res);
	grid = make2DArray(rows,cols);
	for(var i = 0; i<rows; i++){
		for(var j = 0; j<cols; j++){
			grid[i][j] = new Cell(i,j,res);
			bombLocations.push([i,j]);
		}
	}

	//Pick Bomb Locations
	for (var n = 0; n<totalBombs; n++){
		var index = floor(random(bombLocations.length));
		var i = bombLocations[index][0];
		var j = bombLocations[index][1];
		grid[i][j].bomb = true;
		bombLocations.splice(index,1);
	}

	//Count Neighbors
	for(var i = 0; i<rows; i++){
		for(var j = 0; j<cols; j++){
			grid[i][j].countBombNeighbors();
		}
	}
}

function draw() {
	background(51);
	for(var i = 0; i<rows; i++){
		for(var j = 0; j<cols; j++){
			grid[i][j].show();
		}
	}
}

function mouseClicked(){
	for(var i = 0; i<rows; i++){
		for(var j = 0; j<cols; j++){
			if(grid[i][j].contains(mouseX,mouseY)){
				if (mouseButton === LEFT){
					grid[i][j].reveal();
					if (grid[i][j].bomb){
						gameOver();
					}
				}else if (mouseButton === RIGHT){
					grid[i][j].markerMaker();
				}
			}
		}
	}
}

function gameOver(){
	for(var i = 0; i<rows; i++){
		for(var j = 0; j<cols; j++){
			grid[i][j].reveal();
		}
	}
}
